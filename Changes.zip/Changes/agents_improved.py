# agents_new.py - Enhanced with Resilient PubMed Search
# This is the updated main orchestration file integrating the pubmed_resilience module

import os
import asyncio
import pandas as pd
import logging
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent, AzureAIAgentThread
from semantic_kernel.functions import kernel_function
from semantic_kernel.contents import ChatMessageContent
import json
import ast
from datetime import timedelta

# Import resilient PubMed modules
from pubmed_resilience import (
    ResilientPubMedSession,
    GetArticlesResilient,
    GetSearchStringResilient,
    get_or_create_session,
    perform_health_check,
    cleanup_session,
    PubMedConfig
)

# Import custom modules for article details and scoring
from fetch_article_from_id import fetch_pubmed_details, fetch_citation_count
from scoringAgent import init_scoring_agent

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()

# Azure configuration
model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")
pubmed_api_key = os.getenv("PUBMED_API_KEY")

# Initialize Azure AI Project Client
try:
    project_client = AzureAIAgent.create_client(
        credential=AzureCliCredential(),
        conn_str=os.getenv("PROJECT_CONNECTION_STRING")
    )
    logger.info("Azure AI Project Client initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize Azure AI Project Client: {str(e)}")
    raise

# Global state
agent_thread = None
pubmed_session = None


# ============================================================================
# KERNEL FUNCTIONS: GetArticlesResilient Wrapper
# ============================================================================

class GetArticlesKernel:
    """Kernel function wrapper for getting articles from PubMed with resilience."""
    
    def __init__(self, session: ResilientPubMedSession):
        self.fetcher = GetArticlesResilient(session)
    
    @kernel_function(
        name="get_article_ids",
        description="Fetch article IDs from PubMed using search hypothesis with automatic retry and resilience"
    )
    async def get_article_ids(self, hypothesis: str) -> list:
        """
        Fetch article IDs from PubMed with resilience handling.
        
        Args:
            hypothesis: Search term or hypothesis
            
        Returns:
            List of article IDs
        """
        try:
            logger.info(f"Kernel function: Getting articles for hypothesis")
            ids = await self.fetcher.get_article_ids(hypothesis, retmax=PubMedConfig.DEFAULT_RETMAX)
            logger.info(f"Kernel function: Retrieved {len(ids)} articles")
            return ids
        except Exception as e:
            logger.error(f"Kernel function error: {str(e)}")
            return []


class GetSearchStringKernel:
    """Kernel function wrapper for generating optimized PubMed search strings with resilience."""
    
    def __init__(self, session: ResilientPubMedSession):
        self.converter = GetSearchStringResilient(session)
    
    @kernel_function(
        name="get_advanced_query",
        description="Generate optimized PubMed search query string from hypothesis with automatic retry"
    )
    async def get_advanced_query(self, hypothesis: str) -> dict:
        """
        Generate PubMed search string from hypothesis with resilience handling.
        
        Args:
            hypothesis: Research hypothesis
            
        Returns:
            Dictionary mapping hypothesis to search string
        """
        try:
            logger.info(f"Kernel function: Generating search string")
            result = await self.converter.get_advanced_query(hypothesis)
            logger.info(f"Kernel function: Search string generated")
            return result
        except Exception as e:
            logger.error(f"Kernel function error: {str(e)}")
            return {hypothesis: ""}


# ============================================================================
# HELPER FUNCTIONS: Response Processing and Error Handling
# ============================================================================

def clean_markdown_json(text: str) -> str:
    """Remove markdown code fencing from JSON strings."""
    import re
    text = re.sub(r'^```(?:json)?\s*\n?', '', text, flags=re.MULTILINE)
    text = re.sub(r'\n?```$', '', text, flags=re.MULTILINE)
    return text.strip()


async def process_agent_response(response) -> dict:
    """
    Safely extract and parse agent response content.
    
    Args:
        response: Agent response object
        
    Returns:
        Parsed JSON dictionary, or empty dict on error
    """
    try:
        if response is None:
            logger.error("No response from agent")
            return {}
        
        if not hasattr(response, 'message') or response.message is None:
            logger.error("Response has no message attribute")
            return {}
        
        if not hasattr(response.message, 'content') or response.message.content is None:
            logger.error("Message has no content")
            return {}
        
        content = response.message.content
        cleaned_content = clean_markdown_json(content)
        
        parsed_response = json.loads(cleaned_content)
        return parsed_response
        
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {str(e)}")
        return {}
    except Exception as e:
        logger.error(f"Unexpected error processing response: {str(e)}")
        return {}


# ============================================================================
# AGENT INITIALIZATION
# ============================================================================

async def initialize_agents():
    """Initialize all Azure AI agents."""
    
    logger.info("Initializing Azure AI agents...")
    
    global pubmed_session
    
    # Initialize resilient PubMed session
    try:
        pubmed_session = get_or_create_session(pubmed_api_key)
        logger.info("Resilient PubMed session created")
        
        # Perform health check
        health_ok = await perform_health_check()
        if not health_ok:
            logger.warning("PubMed service health check failed, will retry on first request")
    except Exception as e:
        logger.error(f"Failed to initialize PubMed session: {str(e)}")
        raise
    
    # Create Decompose Agent
    try:
        decompose_agent_definition = await project_client.agents.create_agent(
            model=model,
            name="DecomposeAgent",
            instructions="""
You are an expert scientist in hypothesis decomposition for drug discovery and health research. Given a Primary hypothesis: [PRIMARY HYPOTHESIS HERE], decompose it into two categories of sub-hypotheses: (1) Molecular Level (focusing on biochemical, cellular, or mechanistic processes, such as pathways, enzyme interactions, or cellular responses) and (2) Clinical Level (focusing on organ/systemic effects, patient outcomes, or observable health metrics, such as disease progression, symptoms, or cohort studies). For each category, generate exactly 5 sub-hypotheses that are directly inferred from the primary hypothesis and imply it if supported. Phrase each sub-hypothesis as a testable statement. After each sub-hypothesis, always provide a brief rationale (1-2 sentences) explaining why it was chosen and how it links back to the primary. Ensure sub-hypotheses are prioritized based on scientific plausibility from existing literature, without conducting new research.

Output in a structured format: first list the Molecular Level sub-hypotheses (numbered M1-M5 with rationales), then the Clinical Level (numbered C1-C5 with rationales).

Strictly print the output in the said format. Do not add extra commentary.
            """
        )
        Decompose_Agent = AzureAIAgent(
            client=project_client,
            definition=decompose_agent_definition
        )
        logger.info("DecomposeAgent initialized")
    except Exception as e:
        logger.error(f"Failed to initialize DecomposeAgent: {str(e)}")
        raise
    
    # Create Query Fetch Agent
    try:
        queryFetch_agent_definition = await project_client.agents.create_agent(
            model=model,
            name="Query_Fetch_Agent",
            instructions="""
If the sub hypothesis is a molecular sub-hypothesis use the following:

Please act as a PubMed expert and break this [INSERT SUB HYPOTHESIS HERE] given this main hypothesis [INSERT PRIMARY HYPOTHESIS HERE] in to the meaningful search query for PubMed which shall provide relevant results from Meta-analyses, Observational studies and Preclinical studies etc. Do not add extra commentary, just the search string for Pubmed please.

-Always optimize for broader retrieval

Return the output strictly in the following format for hypotheses :

Sub-Hypothesis:
SearchString:

Do not include explanations, reasoning, or any additional text.

If the sub hypothesis is a Clinical sub-hypothesis use the following:

Please act as a PubMed expert and break this [INSERT SUB HYPOTHESIS HERE] given this main hypothesis [INSERT PRIMARY HYPOTHESIS HERE] in to the meaningful search query for PubMed which shall provide relevant results from \"Clinical Trial\" and \"Randomized Control Trial\" only. Do not add extra commentary, just the search string for Pubmed please.

-Always optimize for broader retrieval

Return the output strictly in the following format for hypotheses :

Sub-Hypothesis:
SearchString:

Do not include explanations, reasoning, or any additional text.
            """,
            temperature=0.1,
            top_p=0.01
        )
        Query_Fetch_Agent = AzureAIAgent(
            client=project_client,
            definition=queryFetch_agent_definition,
            polling_options={"timeout": timedelta(minutes=5)}
        )
        logger.info("Query_Fetch_Agent initialized")
    except Exception as e:
        logger.error(f"Failed to initialize Query_Fetch_Agent: {str(e)}")
        raise
    
    # Create Article Fetch Agent with resilient kernel functions
    try:
        articles_kernel = GetArticlesKernel(pubmed_session)
        
        articleFetch_agent_definition = await project_client.agents.create_agent(
            model=model,
            name="Article_Fetch_Agent",
            instructions="""
Use get_article_ids function from GetArticles plugin to fetch article ids using search string : [INPUT SEARCHSTRING].

Output format should be a list of article id strictly as shown below:

[article_id1, article_id2,...]

Do not add extra commentary or anything else.
            """
        )
        Article_Fetch_Agent = AzureAIAgent(
            client=project_client,
            definition=articleFetch_agent_definition,
            plugins=[articles_kernel],
            polling_options={"timeout": timedelta(minutes=5)}
        )
        logger.info("Article_Fetch_Agent initialized")
    except Exception as e:
        logger.error(f"Failed to initialize Article_Fetch_Agent: {str(e)}")
        raise
    
    # Create Main Agent
    try:
        main_agent_definition = await project_client.agents.create_agent(
            model=model,
            name="MainAgent",
            instructions="""
You are a helpful assistant who help users with their hypothesis. You perform following steps:

Step 1 - Call Decompose Agent to break primary hypothesis into sub-hypotheses(5 molecular level and 5 clinical level sub-hypotheses).

Step 2 - Print the actual response of Decompose Agent (sub-hypothesis and rationale).

Step 3 - Ask user to choose the single or multiple sub-hypothesis that user wants to pursue and discard rest.

Step 4 - Return only selected hypotheses with their sub-hypothesis-id in the format {sub-hypothesis-id : sub-hypothesis}

Strictly return JSON output do not add anything else.

Do not rephrase, summarize, or add commentary.
            """
        )
        Main_Agent = AzureAIAgent(
            client=project_client,
            definition=main_agent_definition,
            plugins=[Decompose_Agent],
            polling_options={"timeout": timedelta(minutes=5)}
        )
        logger.info("Main_Agent initialized")
    except Exception as e:
        logger.error(f"Failed to initialize Main_Agent: {str(e)}")
        raise
    
    return {
        "Main_Agent": Main_Agent,
        "Decompose_Agent": Decompose_Agent,
        "Query_Fetch_Agent": Query_Fetch_Agent,
        "Article_Fetch_Agent": Article_Fetch_Agent
    }


# ============================================================================
# MAIN INTERACTION LOOP
# ============================================================================

async def hypolab_agent_interaction():
    """
    Main interaction loop for hypothesis decomposition and evidence retrieval
    with resilient PubMed search.
    """
    global agent_thread, pubmed_session
    
    try:
        # Initialize agents
        agents = await initialize_agents()
        Main_Agent = agents["Main_Agent"]
        Query_Fetch_Agent = agents["Query_Fetch_Agent"]
        Article_Fetch_Agent = agents["Article_Fetch_Agent"]
        
        # Initialize agent thread
        if agent_thread is None:
            agent_thread = AzureAIAgentThread(client=project_client)
            logger.info("Agent thread initialized")
        
        # Main conversation loop
        while True:
            user_input = input("\nUser: ").strip()
            
            if user_input.lower() in {"quit", "exit"}:
                logger.info("User requested exit")
                print("Exiting conversation.")
                break
            
            if not user_input:
                print("Please enter a hypothesis.")
                continue
            
            try:
                # Step 1: Decompose hypothesis
                logger.info("=== STEP 1: Decomposing hypothesis ===")
                print("\nProcessing hypothesis decomposition...")
                
                response = await Main_Agent.get_response(
                    messages=[ChatMessageContent(role="user", content=user_input)],
                    thread=agent_thread
                )
                
                main_response = await process_agent_response(response)
                
                if not main_response:
                    print("Error: Could not parse agent response")
                    continue
                
                print("Assistant:", json.dumps(main_response, indent=2))
                
                # Extract selected hypotheses
                selected_hypothesis = list(main_response.values())
                print(f"\nProcessing {len(selected_hypothesis)} selected hypotheses...")
                logger.info(f"Selected {len(selected_hypothesis)} hypotheses for processing")
                
                # Step 2: Generate search strings
                logger.info("=== STEP 2: Generating search strings ===")
                search_string_dict = {}
                
                for hypothesis in selected_hypothesis:
                    try:
                        logger.debug(f"Generating search string for: {hypothesis[:80]}")
                        query_response = await Query_Fetch_Agent.get_response(
                            messages=hypothesis,
                            thread=agent_thread
                        )
                        
                        query_content = query_response.message.content
                        search_string_dict[hypothesis] = query_content
                        print(f"Generated search string: {query_content[:100]}...")
                        
                    except asyncio.TimeoutError:
                        logger.error(f"Timeout generating search string for: {hypothesis[:80]}")
                        print(f"Timeout for hypothesis: {hypothesis[:80]}")
                        continue
                    except Exception as e:
                        logger.error(f"Error generating search string: {str(e)}")
                        print(f"Error for hypothesis: {hypothesis[:80]}")
                        continue
                
                # Step 3: Fetch articles with resilience
                logger.info("=== STEP 3: Fetching articles from PubMed (with resilience) ===")
                article_id_dict = {}
                
                for sub_hypo, search_string in search_string_dict.items():
                    try:
                        logger.debug(f"Fetching articles for: {sub_hypo[:80]}")
                        print(f"\nFetching articles for hypothesis...")
                        
                        article_response = await Article_Fetch_Agent.get_response(
                            messages=search_string,
                            thread=agent_thread
                        )
                        
                        article_content = article_response.message.content
                        
                        # Parse article IDs with error handling
                        try:
                            article_id_list = ast.literal_eval(article_content)
                            if not isinstance(article_id_list, list):
                                logger.warning(f"Expected list, got {type(article_id_list)}")
                                article_id_list = []
                        except (ValueError, SyntaxError) as e:
                            logger.error(f"Error parsing article IDs: {str(e)}")
                            article_id_list = []
                        
                        article_id_dict[sub_hypo] = article_id_list
                        print(f"Retrieved {len(article_id_list)} articles")
                        
                    except asyncio.TimeoutError:
                        logger.error(f"Timeout fetching articles")
                        print("Timeout while fetching articles")
                        article_id_dict[sub_hypo] = []
                        continue
                    except Exception as e:
                        logger.error(f"Error fetching articles: {str(e)}")
                        print(f"Error fetching articles: {str(e)}")
                        article_id_dict[sub_hypo] = []
                        continue
                
                # Step 4: Fetch article details
                logger.info("=== STEP 4: Fetching article details ===")
                evidence_map = {}
                
                for hypothesis, article_ids in article_id_dict.items():
                    evidences = []
                    for article_id in article_ids:
                        try:
                            logger.debug(f"Fetching details for article {article_id}")
                            evidence = fetch_pubmed_details(article_id, api_key=pubmed_api_key)
                            if evidence:
                                evidences.append(evidence)
                        except Exception as e:
                            logger.error(f"Error fetching article details: {str(e)}")
                            continue
                    
                    evidence_map[hypothesis] = evidences
                    print(f"Retrieved details for {len(evidences)} articles")
                
                # Step 5: Score evidence
                logger.info("=== STEP 5: Scoring evidence ===")
                print("\nScoring evidence quality...")
                
                for hypothesis, articles in evidence_map.items():
                    for article in articles:
                        try:
                            formatted_entry = {
                                "article": {
                                    "title": article.get("title"),
                                    "year": article.get("year"),
                                    "document_text": article.get("document_text")
                                },
                                "hypothesis": hypothesis
                            }
                            
                            score_result = await init_scoring_agent(formatted_entry, agent_thread)
                            print(f"Evidence score: {score_result}")
                            
                        except Exception as e:
                            logger.error(f"Error scoring evidence: {str(e)}")
                            continue
                
                # Print PubMed session statistics
                logger.info("=== SESSION STATISTICS ===")
                if pubmed_session:
                    stats = pubmed_session.get_session_stats()
                    logger.info(f"PubMed session stats: {json.dumps(stats, indent=2)}")
                
            except asyncio.TimeoutError:
                logger.error("Request timed out")
                print("Request timed out. Please try again.")
                continue
            except Exception as e:
                logger.error(f"Error in processing loop: {str(e)}")
                print(f"Error: {str(e)}")
                continue
    
    except Exception as e:
        logger.error(f"Fatal error in interaction: {str(e)}")
        print(f"Fatal error: {str(e)}")
    finally:
        logger.info("Cleaning up resources...")
        cleanup_session()
        print("Resources cleaned up. Goodbye!")


# ============================================================================
# ENTRY POINT
# ============================================================================

if __name__ == "__main__":
    try:
        logger.info("Starting HypoLab Agent Interaction System")
        asyncio.run(hypolab_agent_interaction())
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
        cleanup_session()
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")
        cleanup_session()
