# Enhanced PubMed Search with Resilience and Transient Failure Handling
# This module replaces the GetArticles and GetSearchString classes with robust implementations

import os
import asyncio
import requests
import logging
import time
import hashlib
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from xml.etree import ElementTree
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from functools import wraps

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# ============================================================================
# CONFIGURATION: PubMed API Constants and Retry Strategy
# ============================================================================

class PubMedConfig:
    """Configuration for PubMed API interactions with resilience settings."""
    
    # NCBI PubMed API endpoints
    ESEARCH_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    EINFO_URL = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/einfo.fcgi"
    
    # Rate limiting: NCBI requires minimum 1/3 second per request (max 3 req/sec)
    MIN_REQUEST_DELAY = 0.34  # 340ms minimum between requests
    
    # Retry configuration
    MAX_RETRIES = 3
    INITIAL_BACKOFF = 1  # Start with 1 second
    MAX_BACKOFF = 32     # Cap at 32 seconds
    BACKOFF_MULTIPLIER = 2  # Exponential factor
    JITTER_RANGE = 0.1   # ±10% jitter on backoff
    
    # Timeouts
    REQUEST_TIMEOUT = 15  # seconds per request
    CONNECT_TIMEOUT = 5   # seconds for connection
    
    # Rate limiting: NCBI status codes that indicate throttling
    THROTTLE_STATUS_CODES = {429, 503, 504}
    RETRIABLE_STATUS_CODES = {429, 500, 502, 503, 504}
    
    # Circuit breaker configuration
    CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5  # Fail after 5 consecutive failures
    CIRCUIT_BREAKER_RECOVERY_TIME = 60  # Try again after 60 seconds
    
    # Default search parameters
    DEFAULT_RETMAX = 5
    DEFAULT_RETSTART = 0
    DEFAULT_DB = "pubmed"
    
    # Cache configuration
    CACHE_TTL_SECONDS = 3600  # Cache results for 1 hour
    CACHE_MAX_SIZE = 1000  # Maximum cached entries


class CircuitBreaker:
    """Circuit breaker pattern to prevent cascading failures."""
    
    def __init__(self, failure_threshold: int = 5, recovery_time: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_time = recovery_time
        self.failure_count = 0
        self.last_failure_time = None
        self.state = "CLOSED"  # CLOSED, OPEN, HALF_OPEN
    
    def record_success(self):
        """Record a successful request."""
        self.failure_count = 0
        self.state = "CLOSED"
        logger.debug("Circuit breaker: Request successful, state CLOSED")
    
    def record_failure(self):
        """Record a failed request."""
        self.failure_count += 1
        self.last_failure_time = datetime.now()
        
        if self.failure_count >= self.failure_threshold:
            self.state = "OPEN"
            logger.warning(f"Circuit breaker: OPEN after {self.failure_count} failures")
    
    def is_open(self) -> bool:
        """Check if circuit is open."""
        if self.state == "OPEN":
            if datetime.now() - self.last_failure_time > timedelta(seconds=self.recovery_time):
                self.state = "HALF_OPEN"
                self.failure_count = 0
                logger.info("Circuit breaker: HALF_OPEN, attempting recovery")
                return False
            return True
        return False
    
    def get_status(self) -> Dict[str, any]:
        """Get circuit breaker status."""
        return {
            "state": self.state,
            "failure_count": self.failure_count,
            "last_failure_time": self.last_failure_time.isoformat() if self.last_failure_time else None
        }


class ResponseCache:
    """Simple in-memory cache for API responses."""
    
    def __init__(self, ttl_seconds: int = 3600, max_size: int = 1000):
        self.ttl_seconds = ttl_seconds
        self.max_size = max_size
        self.cache = {}
        self.access_times = {}
    
    def get_key(self, query: str, params: Dict) -> str:
        """Generate cache key from query and parameters."""
        cache_str = f"{query}:{str(sorted(params.items()))}"
        return hashlib.md5(cache_str.encode()).hexdigest()
    
    def get(self, key: str) -> Optional[any]:
        """Get value from cache if not expired."""
        if key in self.cache:
            access_time = self.access_times[key]
            if datetime.now() - access_time < timedelta(seconds=self.ttl_seconds):
                logger.debug(f"Cache hit for key: {key}")
                self.access_times[key] = datetime.now()
                return self.cache[key]
            else:
                # Expired, remove from cache
                del self.cache[key]
                del self.access_times[key]
                logger.debug(f"Cache expired for key: {key}")
        
        return None
    
    def set(self, key: str, value: any) -> None:
        """Store value in cache with expiration."""
        # Simple eviction: remove oldest if at max size
        if len(self.cache) >= self.max_size:
            oldest_key = min(self.access_times, key=self.access_times.get)
            del self.cache[oldest_key]
            del self.access_times[oldest_key]
            logger.debug(f"Cache evicted oldest entry: {oldest_key}")
        
        self.cache[key] = value
        self.access_times[key] = datetime.now()
        logger.debug(f"Cached value for key: {key}")
    
    def clear(self) -> None:
        """Clear entire cache."""
        self.cache.clear()
        self.access_times.clear()
        logger.info("Cache cleared")
    
    def get_stats(self) -> Dict[str, int]:
        """Get cache statistics."""
        return {
            "cached_items": len(self.cache),
            "max_size": self.max_size,
            "ttl_seconds": self.ttl_seconds
        }


class RateLimiter:
    """Token bucket rate limiter for PubMed API."""
    
    def __init__(self, min_delay: float = 0.34):
        self.min_delay = min_delay
        self.last_request_time = None
    
    async def wait_if_needed(self) -> None:
        """Wait if necessary to maintain rate limit."""
        if self.last_request_time:
            elapsed = time.time() - self.last_request_time
            if elapsed < self.min_delay:
                wait_time = self.min_delay - elapsed
                logger.debug(f"Rate limiting: waiting {wait_time:.3f}s")
                await asyncio.sleep(wait_time)
        
        self.last_request_time = time.time()


# ============================================================================
# RETRY MECHANISM: Exponential Backoff with Jitter
# ============================================================================

def create_exponential_backoff():
    """Create an exponential backoff iterator."""
    backoff = PubMedConfig.INITIAL_BACKOFF
    while backoff <= PubMedConfig.MAX_BACKOFF:
        jitter = backoff * PubMedConfig.JITTER_RANGE * (2 * (0.5 - 0.5))  # Random ±jitter
        yield backoff + jitter
        backoff *= PubMedConfig.BACKOFF_MULTIPLIER


async def retry_with_backoff(
    func,
    max_retries: int = PubMedConfig.MAX_RETRIES,
    backoff_generator = None,
    circuit_breaker: Optional[CircuitBreaker] = None
):
    """
    Execute function with exponential backoff retry strategy.
    
    Args:
        func: Async function to execute
        max_retries: Maximum number of retry attempts
        backoff_generator: Iterator for backoff delays
        circuit_breaker: Optional circuit breaker instance
        
    Returns:
        Function result on success
        
    Raises:
        Exception: If all retries exhausted or circuit breaker open
    """
    if backoff_generator is None:
        backoff_generator = create_exponential_backoff()
    
    if circuit_breaker and circuit_breaker.is_open():
        raise Exception("Circuit breaker is OPEN - service unavailable")
    
    last_exception = None
    
    for attempt in range(max_retries + 1):
        try:
            logger.debug(f"Attempt {attempt + 1}/{max_retries + 1}")
            result = await func()
            
            if circuit_breaker:
                circuit_breaker.record_success()
            
            logger.debug("Request successful")
            return result
            
        except Exception as e:
            last_exception = e
            
            if circuit_breaker:
                circuit_breaker.record_failure()
            
            if attempt < max_retries:
                backoff_time = next(backoff_generator)
                logger.warning(
                    f"Request failed (attempt {attempt + 1}): {str(e)}. "
                    f"Retrying in {backoff_time:.2f}s..."
                )
                await asyncio.sleep(backoff_time)
            else:
                logger.error(f"All {max_retries + 1} attempts exhausted")
    
    raise last_exception


# ============================================================================
# HTTP SESSION WITH CONNECTION POOLING
# ============================================================================

class ResilientPubMedSession:
    """HTTP session with connection pooling and automatic retries."""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session = self._create_session()
        self.rate_limiter = RateLimiter(PubMedConfig.MIN_REQUEST_DELAY)
        self.circuit_breaker = CircuitBreaker(
            PubMedConfig.CIRCUIT_BREAKER_FAILURE_THRESHOLD,
            PubMedConfig.CIRCUIT_BREAKER_RECOVERY_TIME
        )
        self.response_cache = ResponseCache(
            PubMedConfig.CACHE_TTL_SECONDS,
            PubMedConfig.CACHE_MAX_SIZE
        )
    
    def _create_session(self) -> requests.Session:
        """Create requests session with connection pooling and retry strategy."""
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=0,  # We handle retries ourselves with exponential backoff
            status_forcelist=list(PubMedConfig.RETRIABLE_STATUS_CODES),
            allowed_methods=["GET"],
            backoff_factor=0
        )
        
        adapter = HTTPAdapter(
            max_retries=retry_strategy,
            pool_connections=10,  # Connection pool size
            pool_maxsize=10
        )
        
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        logger.info("Created HTTP session with connection pooling")
        return session
    
    async def get_with_retry(
        self,
        url: str,
        params: Dict,
        max_retries: int = PubMedConfig.MAX_RETRIES
    ) -> requests.Response:
        """
        Make GET request with retry, rate limiting, and circuit breaker.
        
        Args:
            url: Target URL
            params: Query parameters
            max_retries: Maximum retry attempts
            
        Returns:
            Response object
            
        Raises:
            Exception: If request fails after all retries
        """
        cache_key = self.response_cache.get_key(url, params)
        
        # Check cache first
        cached_response = self.response_cache.get(cache_key)
        if cached_response:
            return cached_response
        
        # Rate limiting
        await self.rate_limiter.wait_if_needed()
        
        # Prepare request with API key
        request_params = {**params, "api_key": self.api_key}
        
        async def make_request():
            response = self.session.get(
                url,
                params=request_params,
                timeout=(PubMedConfig.CONNECT_TIMEOUT, PubMedConfig.REQUEST_TIMEOUT)
            )
            response.raise_for_status()
            return response
        
        try:
            response = await retry_with_backoff(
                make_request,
                max_retries,
                circuit_breaker=self.circuit_breaker
            )
            
            # Cache successful response
            self.response_cache.set(cache_key, response)
            return response
            
        except Exception as e:
            logger.error(f"Request failed: {str(e)}")
            raise
    
    async def health_check(self) -> bool:
        """
        Perform health check on PubMed service.
        
        Returns:
            True if service is available, False otherwise
        """
        try:
            logger.info("Performing PubMed service health check...")
            response = await self.get_with_retry(
                PubMedConfig.EINFO_URL,
                {"db": "pubmed"},
                max_retries=2
            )
            
            if response.status_code == 200:
                logger.info("PubMed service health check: OK")
                return True
        except Exception as e:
            logger.warning(f"Health check failed: {str(e)}")
        
        return False
    
    def get_session_stats(self) -> Dict:
        """Get session statistics."""
        return {
            "cache_stats": self.response_cache.get_stats(),
            "circuit_breaker": self.circuit_breaker.get_status(),
            "rate_limiter_last_request": self.rate_limiter.last_request_time
        }
    
    def close(self) -> None:
        """Close session and cleanup resources."""
        self.session.close()
        self.response_cache.clear()
        logger.info("Session closed and resources cleaned up")


# ============================================================================
# ENHANCED PUBMED SEARCH FUNCTIONS
# ============================================================================

class GetArticlesResilient:
    """Enhanced GetArticles class with transient failure handling."""
    
    def __init__(self, session: ResilientPubMedSession):
        self.session = session
    
    async def get_article_ids(
        self,
        hypothesis: str,
        retmax: int = PubMedConfig.DEFAULT_RETMAX
    ) -> List[str]:
        """
        Fetch article IDs from PubMed with resilience.
        
        Args:
            hypothesis: Search term for PubMed
            retmax: Maximum number of results to return
            
        Returns:
            List of article IDs, or empty list on failure
        """
        try:
            logger.info(f"Fetching article IDs for hypothesis: {hypothesis[:80]}...")
            
            params = {
                "db": PubMedConfig.DEFAULT_DB,
                "term": hypothesis,
                "retmax": retmax,
                "rettype": "json"
            }
            
            response = await self.session.get_with_retry(
                PubMedConfig.ESEARCH_URL,
                params
            )
            
            root = ElementTree.fromstring(response.content)
            id_list = root.find("IdList")
            
            if id_list is None:
                logger.warning(f"No articles found for: {hypothesis[:80]}")
                return []
            
            ids = [elem.text for elem in id_list.findall("Id") if elem.text]
            logger.info(f"Successfully retrieved {len(ids)} article IDs")
            return ids
            
        except Exception as e:
            logger.error(f"Error fetching article IDs: {str(e)}")
            return []


class GetSearchStringResilient:
    """Enhanced GetSearchString class with transient failure handling."""
    
    def __init__(self, session: ResilientPubMedSession):
        self.session = session
    
    async def get_advanced_query(self, hypothesis: str) -> Dict[str, str]:
        """
        Convert hypothesis to optimized PubMed search query with resilience.
        
        Args:
            hypothesis: Research hypothesis
            
        Returns:
            Dictionary mapping hypothesis to search string
        """
        try:
            logger.info(f"Generating search string for: {hypothesis[:80]}...")
            
            params = {
                "db": PubMedConfig.DEFAULT_DB,
                "term": hypothesis,
                "retmax": 1
            }
            
            response = await self.session.get_with_retry(
                PubMedConfig.ESEARCH_URL,
                params
            )
            
            root = ElementTree.fromstring(response.content)
            qt = root.find("QueryTranslation")
            
            # Fixed logic error: changed 'and' to 'or'
            if qt is None or qt.text is None:
                logger.warning(f"No search string found for: {hypothesis[:80]}")
                return {hypothesis: ""}
            
            logger.info(f"Successfully generated search string")
            return {hypothesis: qt.text}
            
        except Exception as e:
            logger.error(f"Error generating search string: {str(e)}")
            return {hypothesis: ""}


# ============================================================================
# CONVENIENCE FUNCTIONS FOR KERNEL INTEGRATION
# ============================================================================

# Global session instance
_pubmed_session = None

def get_or_create_session(api_key: str = None) -> ResilientPubMedSession:
    """Get or create a global PubMed session."""
    global _pubmed_session
    
    if _pubmed_session is None:
        if api_key is None:
            api_key = os.getenv("PUBMED_API_KEY")
            if not api_key:
                raise ValueError("PUBMED_API_KEY environment variable not set")
        
        _pubmed_session = ResilientPubMedSession(api_key)
    
    return _pubmed_session


async def fetch_articles(hypothesis: str, retmax: int = 5) -> List[str]:
    """Convenience function to fetch articles."""
    session = get_or_create_session()
    fetcher = GetArticlesResilient(session)
    return await fetcher.get_article_ids(hypothesis, retmax)


async def get_search_string(hypothesis: str) -> Dict[str, str]:
    """Convenience function to get search string."""
    session = get_or_create_session()
    converter = GetSearchStringResilient(session)
    return await converter.get_advanced_query(hypothesis)


async def perform_health_check() -> bool:
    """Perform health check on PubMed service."""
    session = get_or_create_session()
    return await session.health_check()


# ============================================================================
# CLEANUP
# ============================================================================

def cleanup_session() -> None:
    """Cleanup global session."""
    global _pubmed_session
    if _pubmed_session:
        _pubmed_session.close()
        _pubmed_session = None
        logger.info("Global session cleaned up")
