import os
import pandas as pd
import asyncio
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent
from semantic_kernel.agents import ChatHistoryAgentThread
from azure.ai.projects import AIProjectClient

load_dotenv()

model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")

project_client = AzureAIAgent.create_client(
    credential=AzureCliCredential(),
    conn_str=os.getenv("PROJECT_CONNECTION_STRING")
)

# Helper: read recognized revenue from CSV and parse currency strings to floats
class RecognizedRevenue:
    def __init__(self, csv_path="recognizedRevenue.csv"):
        self.df = pd.read_csv(csv_path)
        # Clean 'Recognized Revenue' column (remove $ and convert to float)
        self.df["Recognized Revenue"] = self.df["Recognized Revenue"].replace('[\$,]', '', regex=True).astype(float)

    def get_revenue_for_company(self, company_name):
        # Sum all revenue entries for the company (you can adjust as needed)
        df_comp = self.df[self.df["Company"].str.lower() == company_name.lower()]
        if df_comp.empty:
            return 0.0
        return df_comp["Recognized Revenue"].sum()

    def get_all_revenues(self):
        # Return dict of company: revenue
        return self.df.groupby("Company")["Recognized Revenue"].sum().to_dict()

# Simulated Historical Payment Data (you should replace with real data or logic)
class HistoricalPayment:
    # Example data:
    payment_rates = {
        "Apple": 0.80,
        "Samsung": 0.75,
        "Dell": 0.62,
        "NVIDIA": 1.00,
        "Qualcomm": 0.90,
        "Amazon": 0.92,
        "Microsoft": 0.88,
        "Google": 0.85,
        "Tesla": 0.68,
        "Lenovo": 0.81,
    }

    def get_on_time_payment(self, company_name):
        return self.payment_rates.get(company_name, 0.5)  # Default 50%

    def get_all_payment_rates(self):
        return self.payment_rates

# CashFlow calculation logic
class CashFlow:
    def __init__(self, recognized_revenue_obj, historical_payment_obj):
        self.revenue_data = recognized_revenue_obj.get_all_revenues()
        self.payment_data = historical_payment_obj.get_all_payment_rates()
        self.outflow = 90000  # Fixed total cash outflow for example

    def calculate(self):
        total_inflow = sum(self.revenue_data.values())
        risky_revenue = 0.0
        risky_customers = []

        for company, revenue in self.revenue_data.items():
            payment_rate = self.payment_data.get(company, 0)
            if payment_rate < 0.7:
                risky_revenue += revenue
                risky_customers.append(company)

        total_cash_flow = total_inflow - self.outflow

        return {
            "total_inflow": total_inflow,
            "total_outflow": self.outflow,
            "risky_revenue": risky_revenue,
            "risky_customers": risky_customers,
            "total_cash_flow": total_cash_flow,
            "company_details": [
                {
                    "company": company,
                    "recognized_revenue": revenue,
                    "on_time_payment": self.payment_data.get(company, 0),
                    "is_risky": self.payment_data.get(company, 0) < 0.7,
                }
                for company, revenue in self.revenue_data.items()
            ],
        }

# Dummy FPA_Agent orchestration simulation (replace with your actual semantic kernel agents)
class FPA_Agent:
    name = "FPA_Agent"

    def __init__(self):
        self.recognized_revenue = RecognizedRevenue()
        self.historical_payment = HistoricalPayment()

    async def get_response(self, messages, thread=None):
        if "cashflow" in messages.lower():
            cf = CashFlow(self.recognized_revenue, self.historical_payment)
            result = cf.calculate()

            response_lines = [
                f"Processing cash flow projection for all companies...",
                f"\n---- Company Analysis ----"
            ]
            for c in result["company_details"]:
                response_lines.append(
                    f"[Analysis]: {c['company']}\n"
                    f"  - Recognized Revenue: ${c['recognized_revenue']:,.0f}\n"
                    f"  - On-time Payment: {c['on_time_payment'] * 100:.1f}%\n"
                    f"  - Risky Customer: {'Yes' if c['is_risky'] else 'No'}"
                )
            response_lines.append(
                f"\n[CashFlow Agent]: Calculated total cash flow with total inflow ${result['total_inflow']:,.0f}, "
                f"outflow ${result['total_outflow']:,.0f}, risky revenue ${result['risky_revenue']:,.0f}."
            )
            response_lines.append(
                f"[FPA_Agent]: Total cash flow for all companies over forecast period is: ${result['total_cash_flow']:,.0f}"
            )

            if result["risky_customers"]:
                risky_str = ", ".join(result["risky_customers"])
                response_lines.append(
                    f"\n[FPA_Agent]: Risky customers detected: {risky_str}."
                )
                response_lines.append(
                    f"[SalesAndAMAgent]: Engaging to negotiate terms for risky customers..."
                )

            return "\n".join(response_lines)

        # Default fallback
        return "I can help with cash flow calculations. Please ask about cashflow for companies."

# Main async loop with proper ChatHistoryAgentThread
async def main():
    fpa_agent = FPA_Agent()
    thread = ChatHistoryAgentThread()  # Single thread for conversation history

    print("Welcome! Start your question. Type 'exit' to quit.\n")

    while True:
        user_input = input("User:> ").strip()
        if user_input.lower() == "exit":
            print("Exiting chat...")
            break

        response = await fpa_agent.get_response(messages=user_input, thread=thread)
        print(f"[{fpa_agent.name}]: {response}\n")

if __name__ == "__main__":
    asyncio.run(main())
