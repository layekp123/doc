import os
import pandas as pd
import asyncio
import datetime
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent, ChatCompletionAgent, ChatHistoryAgentThread
from azure.ai.projects import AIProjectClient
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion

# Load environment
load_dotenv()

model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")
project_client = AzureAIAgent.create_client(
    credential=AzureCliCredential(),
    conn_str=os.getenv("PROJECT_CONNECTION_STRING")
)

# -------------------- TOOL PLUGINS --------------------

class RecognizedRevenue:
    @kernel_function(description="Gets recognized revenue for one or all companies.")
    def get_recognized_revenue(self, companyName: str):
        df = pd.read_csv("recognizedRevenue.csv")
        companyName = companyName.strip().lower()
        if companyName == "all":
            return df.to_dict(orient="records")
        matched = df[df["Company"].str.lower() == companyName]
        return matched.to_dict(orient="records")[0] if not matched.empty else f"Company '{companyName}' not found."

class HistoricalPayment:
    @kernel_function(description="Gets historical on-time payment data.")
    def get_historical_payment_patterns(self, companyName: str):
        df = pd.read_csv("one-time-payment-percent.csv")
        df["Company"] = df["Company"].str.strip().str.lower()
        companyName = companyName.strip().lower()
        if companyName == "all":
            return dict(zip(df["Company"].str.title(), df["On-time Payment Percent"]))
        match = df[df["Company"] == companyName]
        return str(match.iloc[0]["On-time Payment Percent"]) + "%" if not match.empty else f"Company '{companyName}' not found."

class CashFlow:
    @kernel_function(description="Calculates cash flow.")
    def cash_flow_calculation(self, inflow: int, outflow: int, riskyCustomerRevenue: int):
        return inflow - outflow - riskyCustomerRevenue

class ShipmentInformation:
    @kernel_function(description="Stock availability based on number of days.")
    def get_shipment_information(self, noOfDays: int):
        return f"Stocks for {noOfDays} is {'not available' if noOfDays >= 60 else 'available'}."

class InventoryInformation:
    @kernel_function(description="Returns current inventory level.")
    def get_inventory_information(self):
        return "50000"

# -------------------- MAIN FUNCTION --------------------

async def main():
    data_access_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="Data_Access_Agent",
        instructions="You provide data access to tools like revenue, payment, inventory, shipment. Call only when other agents request data."
    )

    DataAccessAgent = AzureAIAgent(
        client=project_client,
        definition=data_access_agent_definition,
        plugins=[
            RecognizedRevenue(),
            HistoricalPayment(),
            ShipmentInformation(),
            InventoryInformation()
        ]
    )

    service = AzureChatCompletion(
        api_key=os.getenv("AZURE_API_KEY"),
        endpoint=os.getenv("AZURE_ENDPOINT"),
        api_version=os.getenv("API_VERSION"),
        deployment_name=model,
    )

    Supply_Chain_Agent = ChatCompletionAgent(
        service=service,
        name="SupplyChainAgent",
        instructions="You handle stock and shipment queries. Call DataAccessAgent to get stock or inventory data.",
        plugins=[DataAccessAgent]
    )

    Finance_Agent = ChatCompletionAgent(
        service=service,
        name="FinanceAgent",
        instructions="You manage finance queries like cashflow and revenue. Use DataAccessAgent to fetch recognized revenue.",
        plugins=[DataAccessAgent]
    )

    Sales_AM_Agent = ChatCompletionAgent(
        service=service,
        name="SalesAndAMAgent",
        instructions='''You assess customer risk using payment history and suggest Net 45 terms for risky customers.
        do not provide any discounts or changes in the plan, the inital plan for every company is Net 90 terms
        - first ask for Net 30 terms
        - if told by FPA agent that its too risky and might effect Customer relations, Suggest Net 45 terms.
        ''',
        plugins=[DataAccessAgent]
    )

    today = datetime.datetime.now()

    FPA_Agent = ChatCompletionAgent(
        service=service,
        name="FPA_Agent",
        instructions=f"""
        You are the orchestrator. Only call agents when needed. 
        If user says 'all companies', retrieve:
        - RecognizedRevenue(all)
        - HistoricalPayment(all)
        For inflow sum up all the recognized revenue of all companies,
        - If on-time payment < 70%, treat as risky
        - Compute cashflow using inflow, outflow=90000, riskyCustomerRevenue=(if risky then inflow else 0)

        DO NOT Call any agents unecessarily follow the following structure for calling agents and call them when asked by user:
        - Call Supply_Chain_Agent for Shipping and Inventory related queries
        - Call Sales_AM_Agent only when asked for a revised plans for risky customer
        - Call Fnance_Agent only to get finance information and to retrieve necesarry data
        - Call DataAccessAgent only to get access to data that you need, if any data is required by any other agent, make them call DataAccessAgent


        include the current date which is {today} and also add number of days
        for which the cashflow projection has to be calculated.for example : if today's date is 26th july 2025 and 
        number of days is 90 , 24th october 2025.

        Please print the response of each Agent along with their name after each call.
        """,
        plugins=[CashFlow(), Supply_Chain_Agent, Sales_AM_Agent, Finance_Agent, DataAccessAgent]
    )

    thread = ChatHistoryAgentThread()
    print("Welcome! Start your question. Type 'exit' to quit.\n")

    async def chat_loop():
        while True:
            try:
                user_input = input("User:> ").strip()
                if user_input.lower() == "exit":
                    print("Exiting...")
                    break

                if "all companies" in user_input.lower():
                    print("[FPA_Agent]: Retrieving cashflow data for all companies...\n")
                    revenue_data = RecognizedRevenue().get_recognized_revenue("all")
                    payment_data = HistoricalPayment().get_historical_payment_patterns("all")

                    print("[DataAccessAgent]: Data fetched.\n")

                    for row in revenue_data:
                        company_name = row["Company"]
                        inflow = int(row.get("Recognized Revenue", 0))
                        outflow = 90000
                        payment_percent = float(payment_data.get(company_name, 100))
                        is_risky = payment_percent < 70
                        risky_revenue = inflow if is_risky else 0

                        cashflow = CashFlow().cash_flow_calculation(
                            inflow=inflow,
                            outflow=outflow,
                            riskyCustomerRevenue=risky_revenue
                        )

                        print(f"📊 Company: {company_name}")
                        print(f"   - Revenue: ${inflow}")
                        print(f"   - On-time Payment: {payment_percent}%")
                        print(f"   - Risky Customer: {'Yes' if is_risky else 'No'}")
                        print(f"   - Cash Flow (90 days): ${cashflow}\n")

                    continue  # skip LLM agent call for this

                # Default: let agent handle input
                response = await FPA_Agent.get_response(messages=user_input, thread=thread)
                print(f"[{FPA_Agent.name}]: {response}")

            except (KeyboardInterrupt, EOFError):
                print("\nExiting...")
                break

    await chat_loop()

# Run
if __name__ == "__main__":
    asyncio.run(main())
