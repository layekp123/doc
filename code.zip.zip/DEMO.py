import os
import pandas as pd
import asyncio
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent, AzureAIAgentSettings, ChatCompletionAgent, ChatHistoryAgentThread
from azure.ai.projects import AIProjectClient
from azure.ai.projects.models import FunctionTool, ToolSet
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion

# Ignore all warnings




load_dotenv()

model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")

project_client = AzureAIAgent.create_client(
    credential=AzureCliCredential(),
    conn_str=os.getenv("PROJECT_CONNECTION_STRING")
)

class RecognizedRevenue:
    @kernel_function(description="Gets recognized revenue, invoice date, billing date, and due date for single or multiple companies.")
    def get_recognized_revenue(self, companyName: str):
        df = pd.read_csv("recognizedRevenue.csv")
        companyName = companyName.strip().lower()

        if companyName == "all":
            return df.to_dict(orient="records")

        matched_row = df[df["Company"].str.lower() == companyName]

        if not matched_row.empty:
            return matched_row.to_dict(orient="records")[0]
        else:
            return f"Company '{companyName}' not found in the data."

class HistoricalPayment:
    @kernel_function(description="Gets historical payment 'on-time' patterns.")
    def get_historical_payment_patterns(self, companyName: str):
        try:
            df = pd.read_csv("one-time-payment-percent.csv")
            df["Company"] = df["Company"].str.strip().str.lower()
            companyName = companyName.strip().lower()

            if companyName == "all":
                return dict(zip(df["Company"].str.title(), df["On-time Payment Percent"]))

            match = df[df["Company"] == companyName]
            if not match.empty:
                return str(match.iloc[0]["On-time Payment Percent"]) + "%"
            else:
                return f"Company '{companyName}' not found in historical data."

        except Exception as e:
            return f"Error reading historical payments: {str(e)}"

class CashFlow:
    @kernel_function(description="Calculates cash flow.")
    def cash_flow_calculation(self, inflow: int, outflow: int, riskyCustomerRevenue: int):
        return inflow - outflow - riskyCustomerRevenue

class ShipmentInformation:
    @kernel_function(description="Checks if the stocks are available for the number of days passed.")
    def get_shipment_information(self, noOfDays: int):
        if noOfDays >= 60:
            return f"Stocks for {noOfDays} is not available."
        else:
            return f"Stocks for {noOfDays} is available."

class InventoryInformation:
    @kernel_function(description="Gets inventory stock size.")
    def get_inventory_information(self):
        return "50000"

async def main():
    data_access_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="Data_Access_Agent",
        instructions="""
        You are a specialized AI agent responsible for providing access to financial data upon request
        by other agents in the system. You hold complete and accurate data for on-time payment history, revenue recognition,
        cash flow calculation, shipment information and inventory information.
        Other agents depend on you to retrieve or analyze data. If recognized revenue is required, call 'RecognizedRevenue()'
        , if historical payment 'on-time' pattern is required, call 'HistoricalPayment()', if inventory stock related enquiry
        comes, call 'InventoryInformation()' and if enquiry comes to Checks if the stocks are available for certain
        number of days then call 'ShipmentInformation()'.

        If recognized revenue data (including invoice, due, and payment dates) is required for one or more companies,
        call 'RecognizedRevenue()'. If the user says "all", return data for all companies. Otherwise, return data for that
        specific company.
        """,
    )

    DataAccessAgent = AzureAIAgent(
        client=project_client,
        definition=data_access_agent_definition,
        plugins=[
            RecognizedRevenue(),
            HistoricalPayment(),
            ShipmentInformation(),
            InventoryInformation()
        ]
    )

    service = AzureChatCompletion(
        api_key=os.getenv("AZURE_API_KEY"),
        endpoint=os.getenv("AZURE_ENDPOINT"),
        api_version=os.getenv("API_VERSION"),
        deployment_name=os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME"),
    )

    Supply_Chain_Agent = ChatCompletionAgent(
        service=service,
        name="SupplyChainAgent",
        instructions="""
        You are a specialized SupplyChain Agent responsible for handling all requests related to inventory
        status and shipment information across the system. Any time inventory or shipping data is requested, you are
        the designated agent to process and fulfill that request. You call a DataAccessAgent for accessing data.  And
        also instruct the DataAccess Agent to fetch stock or inventory data as per requirement.
        """,
        plugins=[DataAccessAgent]
    )

    Finance_Agent = ChatCompletionAgent(
        service=service,
        name="FinanceAgent",
        instructions="""
        You are the Finance Agent. Your responsibility is to respond to cash inflow and outflow related queries,
        as well as queries about recognized revenue details.

        For revenue and invoice-related data (including invoice date, due date, and payment date), call the DataAccessAgent
        using 'RecognizedRevenue()'.

        - If the user asks for data about all companies, pass 'all' as the company name and return the full table.    
        - If the user asks for a specific company, return only that company's data.    

        Note that the total cash outflow is $90,000. If you identify any payment delays or discrepancies, send a message to the FPA Agent.    
        """,
        plugins=[DataAccessAgent]
    )

    Sales_AM_Agent = ChatCompletionAgent(
        service=service,
        name="SalesAndAMAgent",
        instructions="""
        You are the Sales and AM Agent responsible for managing customer payment terms and contracts.
        Your goal is to propose or respond to negotiated terms in a way that minimizes financial risk while maintaining good customer relationships.

        Use DataAccessAgent to retrieve:
        - Call DataAccess agent to callm'HistoricalPayment(companyName) for speicific or 'HistoricalPayment(all)'
        for insights on their behavior.

        Based on the payment risk, agree on appropriate terms:    
        - For high-risk customers, consider Net 45 terms.    
        - Confirm accepted terms and update them in the system using the DataAccessAgent.    
        - Do Not provide any discounts or change in payment contract.
        Always communicate final terms back to the FP&A Agent.    
        """,
        plugins=[DataAccessAgent]
    )
    import datetime

    date_ = datetime.datetime.now()


    FPA_Agent = ChatCompletionAgent(
        service=service,
        name="FPA_Agent",
        instructions=f"""
        You are a FPA Agent (Orchestrator agent). for recognized revenue call ask Data access agent and ask it to call
        RecognizedRevenue() , and forecast cash flow based on
        historical payments pattern, inventory data (Inventory Data from Supply Chain Agent) from DataAccess Agent.
        If any data is required, call DataAccess Agent and provide instruction to it like what kind of data is needed.
        If any company has on-time payment less than '70%' then print 'RiskyCustomer : customer_name'.
        If cash flow calculation is needed then call 'CashFlow()' (If there is no risky customer
        send 0 for riskyCustomerRevenue parameter).

        Also provide reasoning for why a customer is a risky customer.
        while providing cashflow make sure to include the current date which is {date_} and also add number of days
        for which the cashflow projection has to be calculated.for example : if today's date is 26th july 2025 and 
        number of days is 90 , 24th october 2025.

        You communicate with Sales AM agent to agree upon stricter terms for risky customer to reduce their due date.
        agree upon terms For high-risk customers, agree upon the plan intimated my Sales AM agent.
        Do not Reduce it yourself.

        You call Finance Agent to retrieve revenue and invoice-related data (including invoice date, due date, and payment date)    
        , call the Finance agent and fetch data using DataAccessAgent using 'RecognizedRevenue()'.    

        DO NOT Call any agents unecessarily follow the following structure for calling agents and call them when asked by user:
        - Call Supply_Chain_Agent for Shipping and Inventory related queries
        - Call Sales_AM_Agent only when asked for a revised plans for risky customer
        - Call Fnance_Agent only to get finance information and to retrieve necesarry data
        - Call DataAccessAgent only to get access to data that you need, if any data is required by any other agent, make them call DataAccessAgent

        Also Print the name of the agent along with their response when You are calling in each step in [].    
        """,
        plugins=[CashFlow(), Supply_Chain_Agent, Sales_AM_Agent, Finance_Agent, DataAccessAgent]
    )

    thread = project_client.agents.create_thread()

    async def chat(agent: ChatCompletionAgent, thread: ChatHistoryAgentThread = None) -> bool:
        try:
            user_input = input("User:> ")
        except (KeyboardInterrupt, EOFError):
            print("\n\nExiting chat...")
            return False

        if user_input.lower().strip() == "exit":
            print("\n\nExiting chat...")
            return False

        response = await agent.get_response(
            messages=user_input,
            thread=thread,
        )

        if response:
            print(f"[{agent.name}]: {response}")
        return True
    print("Welcome to the chat bot!\n  Type 'exit' to exit.\n")
    chatting = True
    thread = project_client.agents.create_thread()
    thread: ChatHistoryAgentThread = None

    while chatting:
        chatting = await chat(FPA_Agent, thread)
    
    agents = [FPA_Agent, Supply_Chain_Agent, Sales_AM_Agent,Finance_Agent]  # Add others

    async def orchestrate_agents(user_input: str, thread=None):
        for agent in agents:
            response = await agent.get_response(messages=user_input, thread=thread)
            print(f"[{agent.name}]: {response}")
    while True:
        user_input = input("User:> ")
        if user_input.lower().strip() == "exit":
            print("\nExiting chat...")
            break
        await orchestrate_agents(user_input, thread)

# Run the async main    
if __name__ == "__main__":
    asyncio.run(main())