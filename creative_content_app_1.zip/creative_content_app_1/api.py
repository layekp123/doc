from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from agents import create_multi_agent_system
import asyncio

app = FastAPI()

# Input model
class ContentInput(BaseModel):
    campaign_goals: str
    target_audience: str
    brand_guidelines: str
    key_message: str
    social_media_platform: str

@app.post("/generate-content")
async def generate_content(inputs: ContentInput):
    try:
        result = await create_multi_agent_system(inputs.dict())
        return result  # Returns {"strategy": str, "content": str, "image": str}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)