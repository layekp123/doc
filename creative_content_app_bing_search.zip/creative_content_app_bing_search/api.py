from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, validator
from agents import create_multi_agent_system
import asyncio
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI()

# Supported platforms
SUPPORTED_PLATFORMS = {"Twitter", "Facebook", "Instagram"}

# Input model
class ContentInput(BaseModel):
    campaign_goals: str
    target_audience: str
    brand_guidelines: str
    key_message: str
    social_media_platform: str
    use_bing_search: bool = True

    @validator("campaign_goals", "target_audience", "brand_guidelines", "key_message", "social_media_platform")
    def check_non_empty(cls, v):
        if not v.strip():
            raise ValueError("Field cannot be empty or whitespace")
        return v

    @validator("social_media_platform")
    def check_platform(cls, v):
        if v not in SUPPORTED_PLATFORMS:
            raise ValueError(f"Invalid platform. Supported platforms: {', '.join(SUPPORTED_PLATFORMS)}")
        return v

@app.post("/generate-content", response_model=dict)
async def generate_content(inputs: ContentInput):
    logger.info(f"Received request with inputs: {inputs.dict()}")
    try:
        result = await create_multi_agent_system(inputs.dict())
        if "error" in result:
            raise HTTPException(status_code=400, detail={"error": result["error"]})
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        raise HTTPException(status_code=500, detail={"error": f"Failed to generate content: {str(e)}"})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)