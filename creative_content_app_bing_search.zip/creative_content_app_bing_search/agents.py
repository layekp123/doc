import asyncio
import logging
import os
from typing import Annotated, List, Dict
from semantic_kernel import Kernel
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from semantic_kernel.agents import ChatCompletionAgent
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.search.bing import BingSearch
import openai
import base64
from io import BytesIO
from PIL import Image

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Supported platforms
SUPPORTED_PLATFORMS = {"Twitter", "Facebook", "Instagram"}

# Utility function for filtering search results
async def filter_search_results(kernel: Kernel, query: str, keywords: List[str], max_results: int = 3) -> str:
    if "BingSearch" not in kernel.plugins:
        logger.warning("Bing Search plugin not available.")
        return ""
    try:
        search_plugin = kernel.plugins["BingSearch"]
        search_results = await search_plugin.search_async(query, num_results=10)
        filtered_results = []
        for result in search_results:
            if any(keyword.lower() in result["title"].lower() or keyword.lower() in result["snippet"].lower() for keyword in keywords):
                filtered_results.append(f"{result['title']}: {result['snippet']}")
            if len(filtered_results) >= max_results:
                break
        return "\n".join(filtered_results) if filtered_results else "No relevant results found."
    except Exception as e:
        logger.error(f"Error filtering search results: {str(e)}")
        return ""

# Plugin for brand guidelines enforcement
class BrandPlugin:
    @kernel_function(description="Ensures content aligns with brand guidelines.")
    def enforce_guidelines(
        self, content: Annotated[str, "The content to check"], guidelines: Annotated[str, "Brand guidelines"]
    ) -> Annotated[str, "Aligned content"]:
        return f"{content}\n[Aligned with guidelines: {guidelines}]"

# Plugin for audience targeting
class AudiencePlugin:
    @kernel_function(description="Tailors content for the target audience.")
    def tailor_content(
        self, content: Annotated[str, "The content to tailor"], audience: Annotated[str, "Target audience"]
    ) -> Annotated[str, "Tailored content"]:
        return f"{content}\n[Tailored for: {audience}]"

# Plugin for social media optimization
class SocialMediaPlugin:
    @kernel_function(description="Adapts content for the specified social media platform with hashtags.")
    def optimize_for_social(
        self, content: Annotated[str, "The content to optimize"], 
        platform: Annotated[str, "Target platform"]
    ) -> Annotated[str, "Social media optimized content"]:
        hashtags = self.generate_hashtags(content, platform)
        optimized_content = self.optimize_content(content, platform)
        return f"{optimized_content}\nHashtags: {hashtags} #SocialMediaReady"

    def generate_hashtags(self, content: str, platform: str) -> str:
        base_hashtags = ["Creativity", "Brand", "Engage"]
        platform_specific = {
            "Twitter": ["#XTrends", "#SocialMedia"],
            "Facebook": ["#Community", "#Connect"],
            "Instagram": ["#InstaVibes", "#VisualStory"]
        }
        hashtags = base_hashtags + platform_specific.get(platform, [])
        return " ".join([f"#{kw.strip('#')}" for kw in hashtags])

    def optimize_content(self, content: str, platform: str) -> str:
        if platform == "Twitter":
            return content[:250] + "..." if len(content) > 250 else content
        elif platform == "Facebook":
            return content[:450] + "..." if len(content) > 450 else content
        elif platform == "Instagram":
            return content[:900] + "..." if len(content) > 900 else content
        return content

# Function to generate image using Azure OpenAI DALL·E
async def generate_image(prompt: str, api_key: str, endpoint: str, brand_guidelines: str, platform: str) -> str:
    try:
        enhanced_prompt = f"""
        {prompt}
        Align with brand guidelines: {brand_guidelines}.
        """
        client = openai.AsyncOpenAI(
            api_key=api_key,
            base_url=endpoint
        )
        response = await client.images.generate(
            model="dall-e-3",
            prompt=enhanced_prompt,
            size="1024x1024",
            quality="standard",
            n=1,
            response_format="b64_json"
        )
        image_data = response.data[0].b64_json
        return image_data
    except Exception as e:
        logger.error(f"Error generating image: {str(e)}")
        return None

async def create_multi_agent_system(inputs: Dict[str, str]) -> Dict[str, str]:
    # Validate inputs
    required_keys = ["campaign_goals", "target_audience", "brand_guidelines", "key_message", "social_media_platform"]
    for key in required_keys:
        if key not in inputs or not inputs[key].strip():
            logger.error(f"Missing or empty input: {key}")
            return {"error": f"Missing or empty input: {key}"}
    if inputs["social_media_platform"] not in SUPPORTED_PLATFORMS:
        logger.error(f"Invalid social media platform: {inputs['social_media_platform']}")
        return {"error": f"Invalid social media platform: {inputs['social_media_platform']}. Supported platforms: {', '.join(SUPPORTED_PLATFORMS)}"}
    
    # Extract use_bing_search, default to True
    use_bing_search = inputs.get("use_bing_search", True)

    # Initialize kernel
    kernel = Kernel()
    kernel.add_service(
        AzureChatCompletion(
            deployment_name="your-deployment-name",
            endpoint="your-endpoint",
            api_key="your-api-key"
        )
    )

    # Add Bing Search plugin only if enabled
    if use_bing_search:
        bing_api_key = os.getenv("BING_API_KEY", "your-bing-api-key")
        kernel.add_plugin(
            BingSearch(api_key=bing_api_key),
            plugin_name="BingSearch"
        )

    # Define agents
    planner_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="PlannerAgent",
        instructions="You are a strategic planner. Create a content plan based on campaign goals, key message, and USP using provided inputs.",
        plugins=[],
        arguments={}
    )

    content_creator_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="ContentCreatorAgent",
        instructions=f"You are a creative writer. Generate engaging content based on the planner's strategy, key message, and USP. {'Use Bing Search to find audience preferences or trending content.' if use_bing_search else 'Use provided inputs.'}",
        plugins=[AudiencePlugin()] + ([kernel.plugins["BingSearch"]] if use_bing_search else []),
        arguments={}
    )

    editor_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="EditorAgent",
        instructions="You are an editor. Refine content to ensure it aligns with brand guidelines and is polished.",
        plugins=[BrandPlugin()],
        arguments={}
    )

    social_media_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="SocialMediaAgent",
        instructions="You are a social media expert. Optimize content for the specified social media platform, making it concise, engaging, and adding platform-specific hashtags.",
        plugins=[SocialMediaPlugin()],
        arguments={}
    )

    # Hierarchical orchestration
    try:
        # Step 1: Planner creates strategy
        planner_prompt = f"""
        Campaign Goals: {inputs['campaign_goals']}
        Key Message/USP: {inputs['key_message']}
        Create a content strategy based on the provided inputs.
        """
        planner_response = await planner_agent.invoke_async(planner_prompt)
        strategy = planner_response.message.content
        logger.info(f"Planner Strategy generated: {strategy[:100]}...")

        # Step 2: Content Creator generates content
        creator_prompt = f"""
        Strategy: {strategy}
        Key Message/USP: {inputs['key_message']}
        Target Audience: {inputs['target_audience']}
        """
        if use_bing_search:
            search_query = f"{inputs['target_audience']} {inputs['social_media_platform']} social media content preferences 2025"
            search_results = await filter_search_results(
                kernel, 
                search_query, 
                [inputs['target_audience'].lower(), inputs['social_media_platform'].lower(), "content", "social media"], 
                max_results=3
            )
            creator_prompt += f"Search Results: {search_results}\nGenerate creative content incorporating search insights. If no search results, use audience details and strategy."
        else:
            creator_prompt += "Generate creative content based on the provided inputs."
        creator_response = await content_creator_agent.invoke_async(creator_prompt)
        draft_content = creator_response.message.content
        logger.info(f"Draft Content generated: {draft_content[:100]}...")

        # Step 3: Editor refines content
        editor_prompt = f"""
        Draft Content: {draft_content}
        Brand Guidelines: {inputs['brand_guidelines']}
        Refine and align content.
        """
        editor_response = await editor_agent.invoke_async(editor_prompt)
        edited_content = editor_response.message.content
        logger.info(f"Edited Content generated: {edited_content[:100]}...")

        # Step 4: Social Media Agent optimizes content
        social_prompt = f"""
        Edited Content: {edited_content}
        Target Audience: {inputs['target_audience']}
        Social Media Platform: {inputs['social_media_platform']}
        Optimize for the specified platform.
        """
        social_response = await social_media_agent.invoke_async(social_prompt)
        final_content = social_response.message.content
        logger.info(f"Social Media Content generated: {final_content[:100]}...")

        # Step 5: Generate image
        image_prompt = f"""
        Create a vibrant image representing the key message: {inputs['key_message']}.
        Suitable for {inputs['social_media_platform']}.
        """
        image_data = await generate_image(
            prompt=image_prompt,
            api_key="your-api-key",
            endpoint="your-endpoint",
            brand_guidelines=inputs['brand_guidelines'],
            platform=inputs['social_media_platform']
        )

        return {
            "strategy": strategy,
            "content": final_content,
            "image": image_data
        }

    except Exception as e:
        logger.error(f"Error in multi-agent system: {str(e)}")
        return {"error": f"Error generating content: {str(e)}"}