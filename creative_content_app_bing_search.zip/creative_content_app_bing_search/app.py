import streamlit as st
import requests
import base64
from io import BytesIO
from PIL import Image
import logging

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Supported platforms
SUPPORTED_PLATFORMS = {"Twitter", "Facebook", "Instagram"}

st.title("Creative Content Generator")

# Input form
with st.form(key="content_form"):
    campaign_goals = st.text_area("Campaign Goals", placeholder="e.g., Increase brand awareness")
    target_audience = st.text_area("Target Audience", placeholder="e.g., Young professionals, 25-35")
    brand_guidelines = st.text_area("Brand Guidelines", placeholder="e.g., Friendly tone, use blue colors")
    key_message = st.text_area("Key Message/USP", placeholder="e.g., Empowering creativity")
    social_media_platform = st.selectbox("Social Media Platform", list(SUPPORTED_PLATFORMS))
    use_bing_search = st.checkbox("Use Bing Search for Enhanced Content Creation", value=True)
    submit_button = st.form_submit_button("Generate Content")

# Handle form submission
if submit_button:
    # Trim and validate inputs
    inputs = {
        "campaign_goals": campaign_goals.strip() if campaign_goals else "",
        "target_audience": target_audience.strip() if target_audience else "",
        "brand_guidelines": brand_guidelines.strip() if brand_guidelines else "",
        "key_message": key_message.strip() if key_message else "",
        "social_media_platform": social_media_platform
    }
    if not all(v for k, v in inputs.items() if k != "social_media_platform"):
        st.error("Please fill in all text fields with non-whitespace content.")
    elif inputs["social_media_platform"] not in SUPPORTED_PLATFORMS:
        st.error(f"Invalid platform. Supported platforms: {', '.join(SUPPORTED_PLATFORMS)}")
    else:
        logger.info(f"Submitting form with inputs: {inputs}")
        progress = st.progress(0)
        with st.spinner("Generating content and image..."):
            try:
                # Send request to API
                progress.progress(20)
                response = requests.post(
                    "http://localhost:8000/generate-content",
                    json={**inputs, "use_bing_search": use_bing_search}
                )
                response.raise_for_status()
                result = response.json()
                progress.progress(100)

                # Create tabs for Content and Strategy
                tab1, tab2 = st.tabs(["Generated Content", "Content Strategy"])

                # Tab 1: Generated Content and Image
                with tab1:
                    st.success("Content generated successfully!")
                    st.write("### Social Media Content")
                    st.markdown(result["content"])
                    st.info(f"Bing Search {'enabled' if use_bing_search else 'disabled'} for content creation.")
                    if result["image"]:
                        st.write("### Generated Image")
                        image_data = base64.b64decode(result["image"])
                        image = Image.open(BytesIO(image_data))
                        st.image(image, caption="DALL·E-generated image", use_column_width=True)
                    else:
                        st.warning("Image generation failed.")

                # Tab 2: Content Strategy (formatted for leadership)
                with tab2:
                    st.write("### Content Strategy")
                    st.markdown(
                        f"""
                        **Content Strategy for Leadership Review**

                        **Campaign Goals**: {campaign_goals}  
                        **Key Message/USP**: {key_message}  
                        **Target Audience**: {target_audience}  
                        **Social Media Platform**: {social_media_platform}  
                        **Bing Search Enabled**: {'Yes' if use_bing_search else 'No'}

                        **Strategy Overview**:  
                        {result["strategy"]}
                        """,
                        unsafe_allow_html=True
                    )

            except requests.exceptions.HTTPError as e:
                progress.progress(100)
                try:
                    error_detail = e.response.json().get("error", str(e))
                except ValueError:
                    error_detail = str(e)
                st.error(f"API error (HTTP {e.response.status_code}): {error_detail}")
                logger.error(f"API error: {error_detail}")
            except requests.exceptions.RequestException as e:
                progress.progress(100)
                st.error(f"Error connecting to API: {str(e)}")
                logger.error(f"Connection error: {str(e)}")