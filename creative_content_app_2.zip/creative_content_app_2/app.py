import streamlit as st
import requests

st.title("Creative Content Generator")

# Input form
with st.form(key="content_form"):
    campaign_goals = st.text_area("Campaign Goals", placeholder="e.g., Increase brand awareness")
    target_audience = st.text_area("Target Audience", placeholder="e.g., Young professionals, 25-35")
    brand_guidelines = st.text_area("Brand Guidelines", placeholder="e.g., Friendly tone, use blue colors")
    key_message = st.text_area("Key Message/USP", placeholder="e.g., Empowering creativity")
    social_media_platform = st.selectbox("Social Media Platform", ["Twitter", "Facebook", "Instagram"])
    submit_button = st.form_submit_button("Generate Content")

# Handle form submission
if submit_button:
    if not all([campaign_goals, target_audience, brand_guidelines, key_message, social_media_platform]):
        st.error("Please fill in all fields.")
    else:
        with st.spinner("Generating content..."):
            try:
                # Send request to API
                response = requests.post(
                    "http://localhost:8000/generate-content",
                    json={
                        "campaign_goals": campaign_goals,
                        "target_audience": target_audience,
                        "brand_guidelines": brand_guidelines,
                        "key_message": key_message,
                        "social_media_platform": social_media_platform
                    }
                )
                response.raise_for_status()
                result = response.json()

                # Create tabs for Content and Strategy
                tab1, tab2 = st.tabs(["Generated Content", "Content Strategy"])

                # Tab 1: Generated Content
                with tab1:
                    st.success("Content generated successfully!")
                    st.write("### Social Media Content")
                    st.markdown(result["content"])

                # Tab 2: Content Strategy (formatted for leadership)
                with tab2:
                    st.write("### Content Strategy")
                    st.markdown(
                        f"""
                        **Content Strategy for Leadership Review**

                        **Campaign Goals**: {campaign_goals}  
                        **Key Message/USP**: {key_message}  
                        **Target Audience**: {target_audience}  
                        **Social Media Platform**: {social_media_platform}  

                        **Strategy Overview**:  
                        {result["strategy"]}
                        """,
                        unsafe_allow_html=True
                    )

            except requests.exceptions.RequestException as e:
                st.error(f"Error connecting W to API: {str(e)}")