import React, { useState } from 'react';
import ChatPanel from './components/ChatPanel';
import AgentPanel from './components/AgentPanel';
import './styles/App.css';

function App() {
  const [agentsInvolved, setAgentsInvolved] = useState([]);

  return (
    <div className="app-container">
      <h1 className="app-title">Cash Flow Projection</h1>
      <div className="main-layout">
        <ChatPanel setAgentsInvolved={setAgentsInvolved} />
        <AgentPanel agents={agentsInvolved} />
      </div>
    </div>
  );
}

export default App;
