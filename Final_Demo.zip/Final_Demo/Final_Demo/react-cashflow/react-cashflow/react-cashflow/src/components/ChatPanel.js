// // import React, { useState } from 'react';
// // import ReactMarkdown from 'react-markdown';

// // function ChatPanel({ setAgentsInvolved }) {
// //   const [chatHistory, setChatHistory] = useState([]);
// //   const [userInput, setUserInput] = useState('');

// //   const handleSend = async () => {
// //     const userMessage = { role: 'user', content: userInput };
// //     const updatedHistory = [...chatHistory, userMessage];

// //     try {
// //       // const res = await fetch(`http://localhost:8000/ask/run?query=${encodeURIComponent(userInput)}`);
// //       const res = await fetch('http://localhost:8000/ask', {
// //         method: "POST",
// //         headers: { "Content-Type": "application/json" },
// //         body: JSON.stringify({ query: userInput })
// //       });
// //       const data = await res.json();

// //       const assistantMessage = { role: 'assistant', content: data.response };
// //       setChatHistory([...updatedHistory, assistantMessage]);

// //       // ✅ Lift agent state to parent
// //       setAgentsInvolved(data.agents || []);
// //       setUserInput('');
// //     } catch (error) {
// //       console.error('Error fetching response:', error);
// //     }
// //   };

 
// //   return (
// //     <div className="chat-panel">
// //       <h2 className="panel-title" > Analysis</h2>
// //       <div className="chat-history">
// //         {chatHistory.map((msg, idx) => (
// //           <div key={idx} className={`message ${msg.role}`}>
// //             <span className="message-icon">{msg.role === 'user' ? '🧑' : '🤖'}</span>
// //             <span className="message-text">
// //             {msg.content}
// //             </span>
// //           </div>
// //         ))}
// //       </div>
// //       <div className="chat-input-section">
// //         <textarea
// //           className="form-control chat-input"
// //           value={userInput}
// //           onChange={(e) => setUserInput(e.target.value)}
// //           placeholder="Ask a question..."
// //         />
// //         <button className="btn btn-primary send-button" onClick={handleSend}>Send</button>
// //       </div>
// //     </div>
// //   );
// // }

// // export default ChatPanel;
// //-------------------------------------------------------------------------------------------------


// import React, { useState } from 'react';
// import Markdown from 'react-markdown';
// import remarkGfm from 'remark-gfm';

// function ChatPanel({ setAgentsInvolved }) {
//   const [chatHistory, setChatHistory] = useState([]);
//   const [userInput, setUserInput] = useState('');

//   const handleSend = async () => {
//     if (!userInput.trim()) return;

//     const userMessage = { role: 'user', content: userInput };
//     const updatedHistory = [...chatHistory, userMessage];

//     try {
//       const res = await fetch('http://localhost:8000/ask', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ query: userInput }),
//       });

//       const data = await res.json();

//       const assistantMessage = { role: 'assistant', content: data.response };
//       setChatHistory([...updatedHistory, assistantMessage]);

//       // ✅ Lift agent state to parent
//       setAgentsInvolved(data.agents || []);
//       setUserInput('');
//     } catch (error) {
//       console.error('Error fetching response:', error);
//     }
//   };

//   return (
//     <div className="chat-panel">
//       <h2 className="panel-title">Analysis</h2>
//       <div className="chat-history">
//         {chatHistory.map((msg, idx) => (
//           <div key={idx} className={`message ${msg.role}`}>
//             <span className="message-icon">
//               {msg.role === 'user' ? '🧑' : '🤖'}
//             </span>
//             <div className="message-text">
//               <Markdown remarkPlugins={[remarkGfm]}>{msg.content}</Markdown>
//             </div>
//           </div>
//         ))}
//       </div>
//       <div className="chat-input-section">
//         <textarea
//           className="form-control chat-input"
//           value={userInput}
//           onChange={(e) => setUserInput(e.target.value)}
//           placeholder="Ask a question..."
//         />
//         <button className="btn btn-primary send-button" onClick={handleSend}>
//           Send
//         </button>
//       </div>
//     </div>
//   );
// }

// export default ChatPanel;


///////////////////////////////////////////////////////////////////////////////////////

import React, { useState } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

function ChatPanel({ setAgentsInvolved }) {
  const [chatHistory, setChatHistory] = useState([]);
  const [userInput, setUserInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!userInput.trim()) return;

    const userMessage = { role: 'user', content: userInput };
    const updatedHistory = [...chatHistory, userMessage];
    setChatHistory(updatedHistory);
    setLoading(true);

    try {
      const res = await fetch('http://localhost:8000/ask', {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: userInput })
      });

      const data = await res.json();
      const assistantMessage = { role: 'assistant', content: data.response };
      setChatHistory([...updatedHistory, assistantMessage]);
      setAgentsInvolved(data.agents || []);
    } catch (error) {
      console.error('Error fetching response:', error);
      const errorMessage = { role: 'assistant', content: "❌ Failed to get a response." };
      setChatHistory([...updatedHistory, errorMessage]);
    } finally {
      setLoading(false);
      setUserInput('');
    }
  };

  return (
    <div className="chat-panel">
      <h2 className="panel-title">Analysis</h2>
      <div className="chat-history">
        {chatHistory.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>
            <span className="message-icon">{msg.role === 'user' ? '🧑' : '🤖'}</span>
            <span className="message-text">
              <Markdown remarkPlugins={[remarkGfm]}>{msg.content}</Markdown>
            </span>
          </div>
        ))}

        {loading && (
          <div className="message assistant">
            <span className="message-icon">🤖</span>
            <span className="message-text">
              <div className="spinner"></div> Thinking...
            </span>
          </div>
        )}
      </div>

      <div className="chat-input-section">
        <textarea
          className="form-control chat-input"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          placeholder="Ask a question..."
        />
        <button className="btn btn-primary send-button" onClick={handleSend}>Send</button>
      </div>
    </div>
  );
}

export default ChatPanel;
