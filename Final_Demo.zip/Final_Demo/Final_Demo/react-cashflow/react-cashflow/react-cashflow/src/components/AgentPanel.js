// import React, { useState, useEffect } from 'react';

// function AgentPanel({ agents = [] }) {
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//   useEffect(() => {
//     // Simulate loading delay or backend sync
//     const timer = setTimeout(() => {
//       setLoading(false);
//     }, 500); // Adjust delay as needed

//     return () => clearTimeout(timer);
//   }, [agents]);

//   if (error) {
//     return (
//       <div className="agent-panel">
//         <h2 className="panel-title">🤖 Agent Orchestration</h2>
//         <p className="error-message">Error loading agents: {error}</p>
//       </div>
//     );
//   }

//   return (
//     <div className="agent-panel">
//       <h2 className="panel-title">🤖 Agent Orchestration</h2>
//       {loading ? (
//         <p>Loading agents...</p>
//       ) : agents.length === 0 ? (
//         <p>No agents involved yet.</p>
//       ) : (
//         agents.map((agent, idx) => (
//           <div key={idx} className="agent-item">
//             <strong>{agent}</strong> Being Executed...
//             <progress value={100} max={100}></progress>
//           </div>
//         ))
//       )}
//     </div>
//   );
// }

// export default AgentPanel;


//////////////////////////////////////////////////////////////////////////////////////

import React, { useState, useEffect } from 'react';

function AgentPanel({ agents = [] }) {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [progressValues, setProgressValues] = useState({});

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 500);

    return () => clearTimeout(timer);
  }, [agents]);

  useEffect(() => {
    // Initialize progress values to 0 when new agents appear
    const newProgress = {};
    agents.forEach((agent) => {
      newProgress[agent] = 0;
    });
    setProgressValues(newProgress);

    // Animate each agent's progress
    const intervals = agents.map((agent) => {
      return setInterval(() => {
        setProgressValues((prev) => {
          const newValue = Math.min((prev[agent] || 0) + 10, 100);
          return {
            ...prev,
            [agent]: newValue
          };
        });
      }, 100);
    });

    return () => {
      intervals.forEach(clearInterval);
    };
  }, [agents]);

  if (error) {
    return (
      <div className="agent-panel">
        <h2 className="panel-title">🤖 Agent Orchestration</h2>
        <p className="error-message">Error loading agents: {error}</p>
      </div>
    );
  }

  return (
    <div className="agent-panel">
      <h2 className="panel-title">🤖 Agent Orchestration</h2>
      {loading ? (
        <p>Loading agents...</p>
      ) : agents.length === 0 ? (
        <p>No agents involved yet.</p>
      ) : (
        agents.map((agent, idx) => (
          <div key={idx} className="agent-item">
            <strong>{agent}</strong> Being Executed...
            <progress value={progressValues[agent] || 0} max={100}></progress>
          </div>
        ))
      )}
    </div>
  );
}

export default AgentPanel;

