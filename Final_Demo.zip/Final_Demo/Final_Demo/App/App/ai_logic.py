# # ai_logic.py

# import os
# import asyncio
# import pandas as pd
# from dotenv import load_dotenv
# from azure.identity import AzureCliCredential
# from semantic_kernel.agents import AzureAIAgent, AzureAIAgentThread
# from azure.ai.projects import AIProjectClient
# from semantic_kernel.functions import kernel_function

# load_dotenv()

# agent_thread = None

# model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")

# project_client = AzureAIAgent.create_client(
#     credential=AzureCliCredential(),
#     conn_str=os.getenv("PROJECT_CONNECTION_STRING")
# )

# import asyncio
# from semantic_kernel.functions import kernel_function

# class RevenueRealisation:
#     @kernel_function(description="Gets realised revenue (for one or all companies).")
#     async def get_realised_revenue(self, companyName: str):
#         await asyncio.sleep(0)
#         df = pd.read_csv("recognizedRevenue.csv")
#         companyName = companyName.strip().lower()
#         if companyName == "all":
#             return df.to_dict(orient="records")
#         matched = df[df["Company"].str.lower() == companyName]
#         return matched.to_dict(orient="records")[0] if not matched.empty else f"Company '{companyName}' not found."

# class HistoricalPayment:
#     @kernel_function(description="Gets historical payment 'on-time' patterns.")
#     async def get_historical_payment_patterns(self, companyName: str):
#         await asyncio.sleep(0)
#         df = pd.read_csv("ontimePayment.csv")
#         df["Company"] = df["Company"].str.strip().str.lower()
#         companyName = companyName.strip().lower()
#         if companyName == "all":
#             return dict(zip(df["Company"].str.title(), df["On-time Payment Percent"]))
#         match = df[df["Company"] == companyName]
#         return str(match.iloc[0]["On-time Payment Percent"]) + "%" if not match.empty else f"Company '{companyName}' not found."

# class CashFlow:
#     @kernel_function(description="Calculates cash flow.")
#     async def cash_flow_calculation(self, inflow: int, outflow: int):
#         await asyncio.sleep(0)
#         return inflow - outflow

# class CashFlowWithRisk:
#     @kernel_function(description="Calculates cash flow considering risky customers.")
#     async def cash_flow_calculation(self, inflow: int, outflow: int, riskyCustomerRevenue: int):
#         await asyncio.sleep(0)
#         return inflow - outflow - riskyCustomerRevenue

# class ShipmentInformation:
#     @kernel_function(description="Checks if the stocks are available for number of days passed.")
#     async def get_shipment_information(self, noOfDays: int):
#         await asyncio.sleep(0)
#         return f"Stocks for {noOfDays} is {'not ' if noOfDays >= 60 else ''}available."

# class InventoryInformation:
#     @kernel_function(description="Gets inventory stock size.")
#     async def get_inventory_information(self):
#         await asyncio.sleep(0)
#         return "50000"


# # Async wrapper for use in FastAPI
# async def query_supply_chain_agent(user_input: str) -> str:
#     global agent_thread
#     # agents_involved = set()
    
#     data_access_agent_definition = await project_client.agents.create_agent(
#         model=model,
#         name="DataAccessAgent",
#         instructions="""
#         You provide data access to tools like revenue, payment, inventory, shipment. Call only when other agents request data.
#         """
#     )

#     DataAccessAgent = AzureAIAgent(
#         client=project_client,
#         definition=data_access_agent_definition,
#         plugins=[RevenueRealisation(), HistoricalPayment(), ShipmentInformation(), InventoryInformation()]
#     )
#     # agents_involved.add("DataAccessAgent")

#     finance_agent_definition = await project_client.agents.create_agent(
#         model=model,
#         name="FinanceAgent",
#         instructions="""
#         Handle finance-related queries like revenue and cash flow.  Use DataAccessAgent to fetch RevenueRealisation
#         """
#     )

#     FinanceAgent = AzureAIAgent(
#         client=project_client,
#         definition=finance_agent_definition,
#         plugins=[DataAccessAgent]
#     )
#     # agents_involved.add("FinanceAgent")

#     supply_chain_agent_definition = await project_client.agents.create_agent(
#         model=model,
#         name="SupplyChainAgent",
#         instructions="""
#         Handle stock and shipment queries. Call DataAccessAgent to get stock or inventory data.
#     """
#     )
#     SupplyChainAgent = AzureAIAgent(
#         client=project_client,
#         definition=supply_chain_agent_definition,
#         plugins=[DataAccessAgent, FinanceAgent]
#     )
#     # agents_involved.add("SupplyChainAgent")

#     sales_am_agent_definition = await project_client.agents.create_agent(
#         model=model,
#         name="SalesAMAgent",
#         instructions="""
#         You assess customer risk using payment history and suggest Net 15 Days due for risky customers.
#         do not provide any discounts or changes in the plan, the inital plan for every company is Net 30 Days due
#         - first ask for Net 10 Days due
#         - if told by FPA agent that its too risky and might effect Customer relations, Suggest Net 15 Days due.
#     """
#     )
#     SalesAMAgent = AzureAIAgent(
#         client=project_client,
#         definition=sales_am_agent_definition,
#         plugins=[DataAccessAgent]
#     )
#     # agents_involved.add("SalesAMAgent")

#     fpa_agent_definition = await project_client.agents.create_agent(
#         model=model,
#         name="FPA_Agent",
#         instructions="""
#         You are a FPA_agent assiting FPA_managers. Always use professional and collaborative tone, Always address the User by their name while replying.
#         If user says 'all companies', retrieve: RevenueRealisation(all),
#         inflow is calculated as sum of the RevenueRealisation(all) of all companies.
#         outflow is 90000
#         - If the user is asking for cashflow for 'x' days calculate it using the function CashFlow(all) 
#         - Else If the user is asking for cashflow with risk or considering risky customers for 'x' days calculate it using the function CashFlowWithRisk(all)
#         - If on-time payment for any customer is < 70%, treat as risky
#         If the user says Thanks for the recommendation ask the user for any other support needs.
#     """
#     )
#     FPA_Agent = AzureAIAgent(
#         client=project_client,
#         definition=fpa_agent_definition,
#         plugins=[CashFlow(), SupplyChainAgent, SalesAMAgent, FinanceAgent, DataAccessAgent,CashFlowWithRisk()]
#     )
#     # agents_involved.add("FPA_Agent")
    
#     if agent_thread is None:
#         agent_thread = AzureAIAgentThread(client=project_client)

#     response = await FPA_Agent.get_response(messages=user_input, thread=agent_thread)
#     return f"[{FPA_Agent.definition.name}]: {response.message.content}"
#     # all_agents = ["DataAccessAgent", "FinanceAgent", "SalesAMAgent", "SupplyChainAgent", "FPA_Agent"]
#     # return {
#     #     "response": f"[{FPA_Agent.definition.name}]: {response.message.content}",
#     #     "agents": all_
#     # }


################################################################################



# ai_logic.py

import os
import asyncio
import pandas as pd
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent, AzureAIAgentThread
from azure.ai.projects import AIProjectClient
from semantic_kernel.functions import kernel_function

load_dotenv()

agent_thread = None
model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")

project_client = AzureAIAgent.create_client(
    credential=AzureCliCredential(),
    conn_str=os.getenv("PROJECT_CONNECTION_STRING")
)

# === Plugin Classes ===

class RevenueRealisation:
    @kernel_function(description="Gets realised revenue (for one or all companies).")
    async def get_realised_revenue(self, companyName: str):
        await asyncio.sleep(0)
        df = pd.read_csv("recognizedRevenue.csv")
        companyName = companyName.strip().lower()
        if companyName == "all":
            return df.to_dict(orient="records")
        matched = df[df["Company"].str.lower() == companyName]
        return matched.to_dict(orient="records")[0] if not matched.empty else f"Company '{companyName}' not found."

class HistoricalPayment:
    @kernel_function(description="Gets historical payment 'on-time' patterns.")
    async def get_historical_payment_patterns(self, companyName: str):
        await asyncio.sleep(0)
        df = pd.read_csv("ontimePayment.csv")
        df["Company"] = df["Company"].str.strip().str.lower()
        companyName = companyName.strip().lower()
        if companyName == "all":
            return dict(zip(df["Company"].str.title(), df["On-time Payment Percent"]))
        match = df[df["Company"] == companyName]
        return str(match.iloc[0]["On-time Payment Percent"]) + "%" if not match.empty else f"Company '{companyName}' not found."

class CashFlow:
    @kernel_function(description="Calculates cash flow.")
    async def cash_flow_calculation(self, inflow: int, outflow: int):
        await asyncio.sleep(0)
        return inflow - outflow

class CashFlowWithRisk:
    @kernel_function(description="Calculates cash flow considering risky customers.")
    async def cash_flow_calculation(self, inflow: int, outflow: int, riskyCustomerRevenue: int):
        await asyncio.sleep(0)
        return inflow - outflow - riskyCustomerRevenue

class ShipmentInformation:
    @kernel_function(description="Checks if the stocks are available for number of days passed.")
    async def get_shipment_information(self, noOfDays: int):
        await asyncio.sleep(0)
        return f"Stocks for {noOfDays} is {'not ' if noOfDays >= 60 else ''}available."

class InventoryInformation:
    @kernel_function(description="Gets inventory stock size.")
    async def get_inventory_information(self):
        await asyncio.sleep(0)
        return "50000"

# === Async entry point used by FastAPI ===

async def query_supply_chain_agent(user_input: str):
    global agent_thread

    # === Classify the input ===
    lowered = user_input.lower()
    agents_involved = []
    agents_involved.append("FPA_Agent")
    if any(term in lowered for term in ["shipment", "inventory", "stock", "supply", "stocks"]):
        agents_involved.append("SupplyChainAgent")
    if any(term in lowered for term in ["revenue", "cash flow", "cashflow", "finance"]):
        agents_involved.append("FinanceAgent")
    if any(term in lowered for term in [
        "net 30", "net 45", "terms", "payment history", "risky",
        "risk", "negotiate", "renegotiate", "re-negotiate"
    ]):
        agents_involved.append("SalesAndAMAgent")
    


    # === Agent setup ===
    data_access_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="DataAccessAgent",
        instructions="You provide data access to tools like revenue, payment, inventory, shipment. Call only when other agents request data."
    )
    DataAccessAgent = AzureAIAgent(
        client=project_client,
        definition=data_access_agent_definition,
        plugins=[RevenueRealisation(), HistoricalPayment(), ShipmentInformation(), InventoryInformation()]
    )

    finance_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="FinanceAgent",
        instructions="Handle finance-related queries like revenue and cash flow. Use DataAccessAgent to fetch RevenueRealisation"
    )
    FinanceAgent = AzureAIAgent(
        client=project_client,
        definition=finance_agent_definition,
        plugins=[DataAccessAgent]
    )

    supply_chain_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="SupplyChainAgent",
        instructions="Handle stock and shipment queries. Call DataAccessAgent to get stock or inventory data."
    )
    SupplyChainAgent = AzureAIAgent(
        client=project_client,
        definition=supply_chain_agent_definition,
        plugins=[DataAccessAgent, FinanceAgent]
    )

    sales_am_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="SalesAMAgent",
        instructions="""
        You assess customer risk using payment history and suggest Net 15 Days due for risky customers.
        Do not provide any discounts or changes in the plan; the initial plan for every company is Net 30 Days due.
        - First ask for Net 10 Days due
        - If told by FPA agent that it's too risky and might affect customer relations, suggest Net 15 Days due.
        """
    )
    SalesAMAgent = AzureAIAgent(
        client=project_client,
        definition=sales_am_agent_definition,
        plugins=[DataAccessAgent]
    )

    fpa_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="FPA_Agent",
        instructions="""
        You are a FPA_agent assisting FPA_managers. Always use professional and collaborative tone, always address the user by their name.
        If user says 'all companies', retrieve: RevenueRealisation(all),
        inflow is calculated as sum of the RevenueRealisation(all) of all companies.
        outflow is 90000
        - If the user is asking for cashflow for 'x' days calculate it using the function CashFlow(all) after retreiving RevenueRealisation(all) 
        - Else If the user is asking for cashflow with risk or considering risky customers for 'x' days calculate it using the function CashFlowWithRisk(all)
        - If on-time payment for any customer is < 70%, treat as risky
        If the user says Thanks for the recommendation ask the user for any other support needs.
        """
    )
    FPA_Agent = AzureAIAgent(
        client=project_client,
        definition=fpa_agent_definition,
        plugins=[
            CashFlow(), SupplyChainAgent, SalesAMAgent,
            FinanceAgent, DataAccessAgent, CashFlowWithRisk()
        ]
    )

    if agent_thread is None:
        agent_thread = AzureAIAgentThread(client=project_client)

    response = await FPA_Agent.get_response(messages=user_input, thread=agent_thread)

    return {
        "response": f"[{FPA_Agent.definition.name}]: {response.message.content}",
        "agents": agents_involved
    }


