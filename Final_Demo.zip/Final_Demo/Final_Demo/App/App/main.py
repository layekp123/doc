# from fastapi import FastAPI, Request
# from fastapi.middleware.cors import CORSMiddleware
# from ai_logic import query_supply_chain_agent
# import uvicorn

# app = FastAPI()

# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# @app.get("/")
# async def root():
#     return {"message": "Multi Agent Orchestrator API is running."}

# @app.post("/ask")
# async def ask_question(request: Request):
#     data = await request.json()
#     user_input = data.get("query", "")
#     response = await query_supply_chain_agent(user_input)
#     return {"response": response}

# if __name__ == "__main__":
#     uvicorn.run("main:app", port=8000, reload=True)


###########################################################################################


# main.py

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from ai_logic import query_supply_chain_agent
import uvicorn

app = FastAPI()

# Enable CORS for all domains (you can restrict later)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Multi Agent Orchestrator API is running."}

@app.post("/ask")
async def ask_question(request: Request):
    data = await request.json()
    user_input = data.get("query", "")
    
    result = await query_supply_chain_agent(user_input)

    return {
        "response": result["response"],
        "agents": result["agents"]
    }

if __name__ == "__main__":
    uvicorn.run("main:app", port=8000, reload=True)
