import streamlit as st
import requests

st.title("AI Chat Application")

if 'messages' not in st.session_state:
    st.session_state.messages = []

# Display conversation history
for msg in st.session_state.messages:
    if msg["role"] == "user":
        st.write(f"User: {msg['content']}")
    else:
        st.write(f"{msg['content']}")

# Text input for user queries
with st.form("chat_form"):
    user_input = st.text_input("Ask something:")
    submitted = st.form_submit_button("Send")

if submitted and user_input:
    # Send POST request to /chat
    response = requests.post("[invalid url, do not cite] json={"input": user_input})
    bot_response = response.json().get("response")
    
    # Append messages to history
    st.session_state.messages.append({"role": "user", "content": user_input})
    st.session_state.messages.append({"role": "assistant", "content": bot_response})