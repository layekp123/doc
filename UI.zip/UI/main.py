from semantic_kernel import Kernel, kernel_function
from semantic_kernel.agents import AzureAIAgent
from semantic_kernel.connectors.ai.azure_openai import AzureChatCompletion
from azure.identity import DefaultAzureCredential
from fastapi import FastAPI, Request
import asyncio
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = FastAPI()

# Define plugins for MainAgent to call sub-agents
class MainAgentPlugins:
    def __init__(self, data_retrieval_agent, analysis_agent):
        self.data_retrieval_agent = data_retrieval_agent
        self.analysis_agent = analysis_agent

    @kernel_function
    async def call_data_retrieval(self, query: str) -> str:
        return await self.data_retrieval_agent.invoke(query)

    @kernel_function
    async def call_analysis(self, data: str) -> str:
        return await self.analysis_agent.invoke(data)

# Initialize Semantic Kernel and agents
async def init_kernel():
    kernel = Kernel()
    kernel.add_service(AzureChatCompletion(
        deployment_name=os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME", "my-deployment"),
        endpoint=os.getenv("AZURE_AI_AGENT_ENDPOINT"),
        api_key=os.getenv("AZURE_AI_AGENT_API_KEY")
    ))
    async with DefaultAzureCredential() as creds:
        client = await AzureAIAgent.create_client(credential=creds)
        
        # Create DataRetrievalAgent
        data_retrieval_agent = await AzureAIAgent.create_agent(
            name="DataRetrievalAgent",
            instructions="You are responsible for retrieving data from external sources or your knowledge base. When asked to retrieve data about a topic, provide relevant and accurate information.",
            model=AzureChatCompletion(deployment_name=os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME", "my-deployment")),
            client=client,
        )
        
        # Create AnalysisAgent
        analysis_agent = await AzureAIAgent.create_agent(
            name="AnalysisAgent",
            instructions="You are responsible for analyzing data and providing insights. When given data, analyze it thoroughly and provide meaningful insights or summaries.",
            model=AzureChatCompletion(deployment_name=os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME", "my-deployment")),
            client=client,
        )
        
        # Create MainAgentPlugins
        main_agent_plugins = MainAgentPlugins(data_retrieval_agent, analysis_agent)
        
        # Create MainAgent with plugins
        main_agent = await AzureAIAgent.create_agent(
            name="MainAgent",
            instructions="You are an AI assistant that orchestrates tasks. You have access to two tools: 'call_data_retrieval' to retrieve data about a topic, and 'call_analysis' to analyze provided data. Analyze the user's query to determine if it requires data retrieval, analysis, or a general response. Use the appropriate tool when needed and prepare a clear, concise response for the user. If the query is unclear, ask for clarification.",
            model=AzureChatCompletion(deployment_name=os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME", "my-deployment")),
            client=client,
            plugins=[main_agent_plugins]
        )
        
        return kernel, main_agent

# Global variables
kernel = None
main_agent = None
global_thread = None
processing_lock = asyncio.Lock()

@app.on_event("startup")
async def startup_event():
    global kernel, main_agent, global_thread
    kernel, main_agent = await init_kernel()
    global_thread = await main_agent.create_thread()

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    user_input = data.get("input")
    async with processing_lock:
        response_text = await main_agent.invoke(user_input, thread=global_thread)
    return {"response": str(response_text)}