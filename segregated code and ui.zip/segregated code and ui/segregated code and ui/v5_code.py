import asyncio
import os
import pandas as pd
import datetime
from dotenv import load_dotenv
from azure.identity import AzureCliCredential
from semantic_kernel.agents import AzureAIAgent, ChatCompletionAgent, ChatHistoryAgentThread
from azure.ai.projects import AIProjectClient
from semantic_kernel.functions import kernel_function
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion

# Load environment variables
load_dotenv()

model = os.getenv("AZURE_AI_AGENT_MODEL_DEPLOYMENT_NAME")
project_client = AzureAIAgent.create_client(
    credential=AzureCliCredential(),
    conn_str=os.getenv("PROJECT_CONNECTION_STRING")
)

# -------------------- TOOL PLUGINS --------------------
class RevenueRealisation:
    @kernel_function(description="Gets realised revenue( for one or all companies.")
    def get_realised_revenue(self, companyName: str):
        df = pd.read_csv("recognizedRevenue.csv")
        companyName = companyName.strip().lower()
        if companyName == "all":
            return df.to_dict(orient="records")
        matched = df[df["Company"].str.lower() == companyName]
        return matched.to_dict(orient="records")[0] if not matched.empty else f"Company '{companyName}' not found."

class HistoricalPayment:
    @kernel_function(description="Gets historical on-time payment data.")
    def get_historical_payment_patterns(self, companyName: str):
        df = pd.read_csv("ontimePayment.csv")
        df["Company"] = df["Company"].str.strip().str.lower()
        companyName = companyName.strip().lower()
        if companyName == "all":
            return dict(zip(df["Company"].str.title(), df["On-time Payment Percent"]))
        match = df[df["Company"] == companyName]
        return str(match.iloc[0]["On-time Payment Percent"]) + "%" if not match.empty else f"Company '{companyName}' not found."

class CashFlow:
    @kernel_function(description="Calculates cash flow.")
    def cash_flow_calculation(self, inflow: int, outflow: int):
        return inflow - outflow

class CashFlowWithRisk:
    @kernel_function(description="Calculates cash flow considering risky customers.")
    def cash_flow_calculation(self, inflow: int, outflow: int, riskyCustomerRevenue: int):
        return inflow - outflow - riskyCustomerRevenue

class ShipmentInformation:
    @kernel_function(description="Stock availability based on number of days.")
    def get_shipment_information(self, noOfDays: int):
        return f"Stocks for {noOfDays} days is {'not available' if noOfDays >= 60 else 'available'}."

class InventoryInformation:
    @kernel_function(description="Returns current inventory level.")
    def get_inventory_information(self):
        return "50000"

# -------------------- AGENT ORCHESTRATION --------------------
async def run_fpa_agent(user_input, thread):
    data_access_agent_definition = await project_client.agents.create_agent(
        model=model,
        name="Data_Access_Agent",
        instructions="You provide data access to tools like revenue, payment, inventory, shipment. Call only when other agents request data."
    )

    DataAccessAgent = AzureAIAgent(
        client=project_client,
        definition=data_access_agent_definition,
        plugins=[RevenueRealisation(), HistoricalPayment(), ShipmentInformation(), InventoryInformation()]
    )

    service = AzureChatCompletion(
        api_key=os.getenv("AZURE_API_KEY"),
        endpoint=os.getenv("AZURE_ENDPOINT"),
        api_version=os.getenv("API_VERSION"),
        deployment_name=model,
    )

    SupplyChainAgent = ChatCompletionAgent(
        service=service,
        name="SupplyChainAgent",
        instructions="Handle stock and shipment queries. Call DataAccessAgent to get stock or inventory data.",
        plugins=[DataAccessAgent],
    )

    FinanceAgent = ChatCompletionAgent(
        service=service,
        name="FinanceAgent",
        instructions="Handle finance-related queries like revenue and cash flow.  Use DataAccessAgent to fetch RevenueRealisation",
        plugins=[DataAccessAgent, CashFlow(), CashFlowWithRisk()]
    )

    SalesAMAgent = ChatCompletionAgent(
        service=service,
        name="SalesAndAMAgent",
        instructions='''You assess customer risk using payment history and suggest Net 15 Days due for risky customers.
        do not provide any discounts or changes in the plan, the inital plan for every company is Net 30 Days due
        - first ask for Net 10 Days due
        - if told by FPA agent that its too risky and might effect Customer relations, Suggest Net 15 Days due.
        ''',
        plugins=[DataAccessAgent]
    )

    FPA_Agent = ChatCompletionAgent(
        service=service,
        name="FPA_Agent",
        instructions="""
        You are a FPA_agent assiting FPA_managers. Always use professional and collaborative tone, Always address the User by their name while replying.
        If user says 'all companies', retrieve: RevenueRealisation(all),
        inflow is calculated as sum of the RevenueRealisation(all) of all companies.
        outflow is 90000
        - If the user is asking for cashflow for 'x' days calculate it using the function CashFlow(all) 
        - Else If the user is asking for cashflow with risk or considering risky customers for 'x' days calculate it using the function CashFlowWithRisk(all)
        - If on-time payment for any customer is < 70%, treat as risky
        If the user says Thanks for the recommendation ask the user for any other support needs.
        

""",
        plugins=[CashFlow(), SupplyChainAgent, SalesAMAgent, FinanceAgent, DataAccessAgent, CashFlowWithRisk()]
    )

    lowered = user_input.lower()
    log_lines = []
    inferred_agents = []

    if "all companies" in lowered:
        inferred_agents = ["FPA_Agent", "DataAccessAgent"]
        revenue_data = RevenueRealisation().get_realised_revenue("all")
        payment_data = HistoricalPayment().get_historical_payment_patterns("all")

        results = ["[FPA_Agent]: Retrieving cashflow data for all companies...", "[DataAccessAgent]: Data fetched."]
        for row in revenue_data:
            company_name = row["Company"]
            inflow = int(row.get("Revenue_Realisation", 0))
            outflow = 90000
            payment_percent = float(payment_data.get(company_name, 100))
            is_risky = payment_percent < 70
            risky_revenue = inflow if is_risky else 0

            cashflow = CashFlowWithRisk().cash_flow_calculation(inflow, outflow, risky_revenue)
            results.append(f"📊 {company_name} | Revenue: ${inflow} | On-time: {payment_percent}% | Risky: {'Yes' if is_risky else 'No'} | Cash Flow: ${cashflow}")
        return "\n".join(results), inferred_agents

    # === Agent detection logic ===
    if any(term in lowered for term in ["shipment", "inventory", "stock", "supply", "stocks"]):
        log_lines.append("**SupplyChainAgent is being called to handle the task.**")
        inferred_agents.append("SupplyChainAgent")

    if any(term in lowered for term in ["revenue", "cash flow", "cashflow", "finance"]):
        log_lines.append("**FinanceAgent is being called to handle the task.**")
        inferred_agents.append("FinanceAgent")

    if any(term in lowered for term in ["net 30", "net 45", "terms", "payment history", "risky", "risk", "negotiate", "renegotiate", "re-negotiate", "revised"]):
        log_lines.append("**SalesAndAMAgent is being called to handle the task.**")
        inferred_agents.append("SalesAndAMAgent")

    if not inferred_agents:
        log_lines.append("**FPA_Agent is orchestrating the query.**")

    inferred_agents.insert(0, "FPA_Agent")  # FPA is always first

    response = await FPA_Agent.get_response(messages=user_input, thread=thread)
    return "\n\n".join(log_lines + [f"[{FPA_Agent.name}]:\n{response}"]), inferred_agents
