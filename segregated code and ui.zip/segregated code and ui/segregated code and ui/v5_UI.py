import streamlit as st
from v5_code import *

def main():
    st.set_page_config(page_title="Cash Flow Projection", layout="wide")

    st.title("🧠 Cash Flow Projection")

    # Layout: Chat + Agent flow (3:1 ratio)
    chat_col, agent_col = st.columns([3, 1])

    if "thread" not in st.session_state:
        st.session_state.thread = ChatHistoryAgentThread()
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "agent_log" not in st.session_state:
        st.session_state.agent_log = []

    # === Chat UI ===
    with chat_col:
        st.subheader("💬 Analysis")

        for entry in st.session_state.chat_history:
            with st.chat_message(entry["role"]):
                st.markdown(entry["content"])

        user_input = st.chat_input("Ask a question...")

        if user_input:
            st.session_state.chat_history.append({"role": "user", "content": user_input})
            with st.chat_message("user"):
                st.markdown(user_input)

            with st.chat_message("assistant"):
                with st.spinner("Thinking..."):
                    response, agents_involved = asyncio.run(run_fpa_agent(user_input, st.session_state.thread))
                st.markdown(response)
                st.session_state.chat_history.append({"role": "assistant", "content": response})
                st.session_state.agent_log.append((user_input, agents_involved))

    # === Agent Progress UI with gradual progress bars ===
    with agent_col:
        
        st.subheader("🤖 Agent Orchestration")

        if st.session_state.agent_log:
            latest_query, used_agents = st.session_state.agent_log[-1]

            # Make sure FPA_Agent is first in flow
            flow = ["FPA_Agent"] + [a for a in used_agents if a != "FPA_Agent"]

            for idx, agent in enumerate(flow):
                st.markdown(f"**{agent}** Being Executed... ")
                progress = st.progress(0)
                for pct in range(0, 101, 10):
                    progress.progress(pct)
                    # Use asyncio.sleep to simulate asynchronous delay for smooth progress animation
                    asyncio.run(asyncio.sleep(0.05))



if __name__ == "__main__":
    main()
