import asyncio
import logging
import os
from typing import Annotated
from semantic_kernel import Kernel
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from semantic_kernel.agents import ChatCompletionAgent
from semantic_kernel.agents.group_chat import GroupChat
from semantic_kernel.functions import kernel_function
from openai import AsyncOpenAI
import base64
from io import BytesIO
from PIL import Image
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Plugin for brand guidelines enforcement
class BrandPlugin:
    @kernel_function(description="Ensures content aligns with brand guidelines.")
    def enforce_guidelines(
        self, content: Annotated[str, "The content to check"], guidelines: Annotated[str, "Brand guidelines"]
    ) -> Annotated[str, "Aligned content"]:
        return f"{content}\n[Aligned with guidelines: {guidelines}]"

# Plugin for audience targeting
class AudiencePlugin:
    @kernel_function(description="Tailors content for the target audience.")
    def tailor_content(
        self, content: Annotated[str, "The content to tailor"], audience: Annotated[str, "Target audience"]
    ) -> Annotated[str, "Tailored content"]:
        return f"{content}\n[Tailored for: {audience}]"

# Plugin for social media optimization
class SocialMediaPlugin:
    @kernel_function(description="Adapts content for the specified social media platform with hashtags.")
    def optimize_for_social(
        self, content: Annotated[str, "The content to optimize"], platform: Annotated[str, "Target platform"]
    ) -> Annotated[str, "Social media optimized content"]:
        hashtags = self.generate_hashtags(content, platform)
        optimized_content = self.optimize_content(content, platform)
        return f"{optimized_content}\nHashtags: {hashtags} #SocialMediaReady"

    def generate_hashtags(self, content: str, platform: str) -> str:
        base_hashtags = ["Creativity", "Brand", "Engage"]
        platform_specific = {
            "Twitter": ["#XTrends", "#SocialMedia"],
            "Facebook": ["#Community", "#Connect"],
            "Instagram": ["#InstaVibes", "#VisualStory"]
        }
        hashtags = base_hashtags + platform_specific.get(platform, [])
        return " ".join([f"#{kw}" for kw in hashtags])

    def optimize_content(self, content: str, platform: str) -> str:
        if platform == "Twitter":
            return content[:250] + "..." if len(content) > 250 else content
        elif platform == "Facebook":
            return content[:450] + "..." if len(content) > 450 else content
        elif platform == "Instagram":
            return content[:900] + "..." if len(content) > 900 else content
        return content

# Function to generate image using Azure OpenAI DALL·E
async def generate_image(prompt: str, api_key: str, endpoint: str) -> str:
    try:
        client = AsyncOpenAI(
            api_key=api_key,
            base_url=endpoint
        )
        response = await client.images.generate(
            model="dall-e-3",  # Fixed typo
            prompt=prompt,
            size="1024x1024",
            quality="standard",
            n=1,
            response_format="b64_json"
        )
        if response.data and response.data[0].b64_json:
            return response.data[0].b64_json
        else:
            logger.error("No image data returned from DALL·E")
            return None
    except Exception as e:
        logger.error(f"Error generating image: {str(e)}")
        return None

# Custom termination condition
def termination_condition(chat_history) -> bool:
    has_strategy = False
    has_content = False
    for message in chat_history.messages:
        # Check for Moderator's termination signal
        if message.sender == "ModeratorAgent" and "TERMINATE" in message.content:
            return True
        # Check for strategy and content presence
        if message.sender == "PlannerAgent" and "strategy" in message.content.lower():
            has_strategy = True
        if message.sender == "SocialMediaAgent" and "Hashtags" in message.content:
            has_content = True
    # Terminate if both strategy and content are present
    return has_strategy and has_content

async def create_multi_agent_group_chat(inputs: dict) -> dict:
    # Validate platform
    valid_platforms = ["Twitter", "Facebook", "Instagram"]
    if inputs.get("social_media_platform") not in valid_platforms:
        return {"strategy": "", "content": "Error: Invalid social media platform.", "image": None}

    # Initialize kernel
    kernel = Kernel()
    kernel.add_service(
        AzureChatCompletion(
            deployment_name=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
            api_key=os.getenv("AZURE_OPENAI_API_KEY")
        )
    )

    # Define agents
    moderator_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="ModeratorAgent",
        instructions="""
        You are a moderator overseeing a group chat to produce a content strategy and social media content. Your role is to:
        - Guide the conversation to align with campaign goals, key message, target audience, brand guidelines, and platform.
        - Ensure each agent contributes appropriately:
          - Planner: Propose a content strategy.
          - Content Creator: Generate draft content.
          - Editor: Refine content for brand alignment.
          - Social Media: Optimize content with platform-specific hashtags.
        - Monitor progress and validate:
          1. A content strategy exists (from Planner or your summary).
          2. Final content is optimized with hashtags (from Social Media Agent).
          3. Outputs align with inputs (goals, audience, platform, guidelines).
        - If both are complete and valid, provide a clear summary of the strategy and content, then send a message with "TERMINATE" to end the chat.
        - Redirect off-topic contributions and resolve conflicts.
        - Ensure content is concise and hashtags are platform-appropriate.
        """,
        plugins=[],
        arguments={}
    )

    planner_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="PlannerAgent",
        instructions="You are a strategic planner. Propose a content strategy based on campaign goals and key message. Label your output as 'Content Strategy:'.",
        plugins=[],
        arguments={}
    )

    content_creator_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="ContentCreatorAgent",
        instructions="You are a creative writer. Generate engaging content based on the strategy and key message, tailored to the target audience. Label your output as 'Draft Content:'.",
        plugins=[AudiencePlugin()],
        arguments={}
    )

    editor_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="EditorAgent",
        instructions="You are an editor. Refine content to ensure it aligns with brand guidelines and is polished. Label your output as 'Edited Content:'.",
        plugins=[BrandPlugin()],
        arguments={}
    )

    social_media_agent = ChatCompletionAgent(
        service=kernel.services["azure_chat_completion"],
        name="SocialMediaAgent",
        instructions="You are a social media expert. Optimize content for the specified platform with appropriate hashtags. Label your output as 'Optimized Content:'.",
        plugins=[SocialMediaPlugin()],
        arguments={}
    )

    # Initialize group chat with termination strategy
    group_chat = GroupChat(
        agents=[moderator_agent, planner_agent, content_creator_agent, editor_agent, social_media_agent],
        admin=moderator_agent,
        max_rounds=10,
        termination_condition=termination_condition
    )

    # Initial prompt for group chat
    initial_prompt = f"""
    Campaign Goals: {inputs['campaign_goals']}
    Key Message/USP: {inputs['key_message']}
    Target Audience: {inputs['target_audience']}
    Brand Guidelines: {inputs['brand_guidelines']}
    Social Media Platform: {inputs['social_media_platform']}

    Moderator: Start the collaboration to create a content strategy and social media content. Ensure alignment with the above inputs. Each agent should label their output clearly (e.g., 'Content Strategy:', 'Optimized Content:'). Summarize the final strategy and content, and send "TERMINATE" when complete.
    """

    try:
        # Run group chat
        chat_history = await group_chat.invoke_async(initial_prompt)
        
        # Extract strategy and content from the chat history
        strategy = ""
        final_content = ""
        for message in reversed(chat_history.messages):  # Prioritize latest messages
            if not strategy and message.sender == "PlannerAgent" and message.content.startswith("Content Strategy:"):
                strategy = message.content.replace("Content Strategy:", "").strip()
            if not final_content and message.sender == "SocialMediaAgent" and message.content.startswith("Optimized Content:"):
                final_content = message.content.replace("Optimized Content:", "").strip()
            if message.sender == "ModeratorAgent" and "summary" in message.content.lower():
                # Parse Moderator's summary
                lines = message.content.split("\n")
                for line in lines:
                    if line.startswith("Strategy:") and not strategy:
                        strategy = line.replace("Strategy:", "").strip()
                    if line.startswith("Content:") and not final_content:
                        final_content = line.replace("Content:", "").strip()

        # Generate image with DALL·E
        image_prompt = f"""
        Create a vibrant image representing the key message: {inputs['key_message']}.
        Align with brand guidelines: {inputs['brand_guidelines']}.
        Suitable for {inputs['social_media_platform']}.
        """
        image_data = await generate_image(
            prompt=image_prompt,
            api_key=os.getenv("AZURE_OPENAI_API_KEY"),
            endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
        )

        return {
            "strategy": strategy or "No strategy generated.",
            "content": final_content or "No content generated.",
            "image": image_data
        }

    except Exception as e:
        logger.error(f"Error in group chat: {str(e)}")
        return {"strategy": "", "content": f"Error generating content: {str(e)}", "image": None}