from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from agents import create_multi_agent_group_chat
import asyncio

app = FastAPI()

# Input model
class ContentInput(BaseModel):
    campaign_goals: str
    target_audience: str
    brand_guidelines: str
    key_message: str
    social_media_platform: str

@app.post("/generate-content")
async def generate_content(inputs: ContentInput):
    # Validate inputs
    if not all([inputs.campaign_goals, inputs.target_audience, inputs.brand_guidelines, inputs.key_message, inputs.social_media_platform]):
        raise HTTPException(status_code=400, detail="All input fields are required.")
    
    try:
        result = await create_multi_agent_group_chat(inputs.dict())
        if "Error" in result["content"]:
            raise HTTPException(status_code=500, detail=result["content"])
        return result  # Returns {"strategy": str, "content": str, "image": str}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Server error: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)